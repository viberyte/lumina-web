import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated } from 'react-native';
import { colors, typography, spacing } from '../theme';

interface ButtonGroupProps {
  options: string[];
  onSelect: (option: string) => void;
  columns?: 1 | 2;
}

export default function ButtonGroup({ options, onSelect, columns = 1 }: ButtonGroupProps) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        delay: 200,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        delay: 200,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handlePress = (option: string) => {
    onSelect(option);
  };

  return (
    <Animated.View 
      style={[
        styles.container, 
        columns === 2 && styles.grid,
        {
          opacity: fadeAnim,
          transform: [{ scale: scaleAnim }],
        }
      ]}
    >
      {options.map((option) => (
        <TouchableOpacity
          key={option}
          style={[styles.button, columns === 2 && styles.gridButton]}
          onPress={() => handlePress(option)}
          activeOpacity={0.7}
        >
          <Text style={styles.buttonText}>{option}</Text>
        </TouchableOpacity>
      ))}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  button: {
    backgroundColor: colors.glass.medium,
    borderWidth: 1,
    borderColor: colors.glass.border,
    borderRadius: 20,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm + 2,
    marginBottom: spacing.sm,
  },
  gridButton: {
    flex: 1,
    minWidth: '47%',
    marginBottom: 0,
  },
  buttonText: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.light,
    color: colors.white,
    textAlign: 'center',
  },
});
