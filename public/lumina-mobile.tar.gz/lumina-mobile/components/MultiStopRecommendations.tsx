import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

interface MultiStopProps {
  venueId: number;
}

export default function MultiStopRecommendations({ venueId }: MultiStopProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [recommendations, setRecommendations] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchRecommendations();
  }, [venueId]);

  const fetchRecommendations = async () => {
    try {
      setLoading(true);
      const response = await fetch('https://lumina.viberyte.com/api/multi-stop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          primaryVenueId: venueId,
          dateSelection: { type: 'tonight' },
        }),
      });

      const data = await response.json();
      
      if (data.error) {
        setError(data.message || 'Could not load recommendations');
      } else {
        setRecommendations(data.recommendations);
      }
    } catch (err) {
      console.error('Multi-stop fetch error:', err);
      setError('Failed to load recommendations');
    } finally {
      setLoading(false);
    }
  };

  const handleVenuePress = (venue: any, type: string) => {
    if (type === 'event') {
      router.push(`/event/${venue.id}`);
    } else {
      router.push(`/venue/${venue.id}`);
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'safe': return '#10b981';
      case 'elevated': return '#8b5cf6';
      case 'wildcard': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const getTierLabel = (tier: string) => {
    switch (tier) {
      case 'safe': return '🛡️ Safe & Cozy';
      case 'elevated': return '✨ Elevated Vibes';
      case 'wildcard': return '🎲 Wildcard Energy';
      default: return '';
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#8b5cf6" />
        <Text style={styles.loadingText}>Finding your next stop...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  if (!recommendations) return null;

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>🌆 Continue Your Night</Text>
      <Text style={styles.subtitle}>Choose your vibe for the next stop</Text>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.carousel}>
        {['safe', 'elevated', 'wildcard'].map((tier) => {
          const rec = recommendations[tier];
          if (!rec) return null;

          return (
            <TouchableOpacity
              key={tier}
              style={[styles.card, { borderColor: getTierColor(tier) }]}
              onPress={() => handleVenuePress(rec.venue, rec.type)}
              activeOpacity={0.8}
            >
              <View style={[styles.badge, { backgroundColor: getTierColor(tier) }]}>
                <Text style={styles.badgeText}>{getTierLabel(tier)}</Text>
              </View>

              <Image
                source={{ uri: rec.venue.photo || 'https://via.placeholder.com/300x200' }}
                style={styles.venueImage}
              />

              <View style={styles.info}>
                <Text style={styles.venueName} numberOfLines={1}>
                  {rec.venue.name}
                </Text>
                <Text style={styles.cuisine} numberOfLines={1}>
                  {rec.venue.cuisine}
                </Text>

                <View style={styles.reasoningBox}>
                  <Ionicons name="bulb-outline" size={16} color="#fbbf24" />
                  <Text style={styles.reasoning} numberOfLines={2}>
                    {rec.reasoning}
                  </Text>
                </View>

                <View style={styles.travelInfo}>
                  <Ionicons name="time-outline" size={14} color="#9ca3af" />
                  <Text style={styles.travelTime}>{rec.travelTime}</Text>
                </View>

                <View style={styles.proTipBox}>
                  <Text style={styles.proTip}>💡 {rec.proTip}</Text>
                </View>
              </View>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginTop: 24, marginBottom: 16 },
  sectionTitle: { fontSize: 22, fontWeight: '700', color: '#fff', marginBottom: 4, paddingHorizontal: 16 },
  subtitle: { fontSize: 14, color: '#9ca3af', marginBottom: 16, paddingHorizontal: 16 },
  carousel: { paddingLeft: 16 },
  card: { width: 280, backgroundColor: 'rgba(17, 24, 39, 0.9)', borderRadius: 16, marginRight: 12, borderWidth: 2, overflow: 'hidden' },
  badge: { position: 'absolute', top: 12, left: 12, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, zIndex: 10 },
  badgeText: { fontSize: 12, fontWeight: '700', color: '#fff' },
  venueImage: { width: '100%', height: 160, backgroundColor: '#1f2937' },
  info: { padding: 12 },
  venueName: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 4 },
  cuisine: { fontSize: 13, color: '#9ca3af', marginBottom: 8 },
  reasoningBox: { flexDirection: 'row', alignItems: 'flex-start', backgroundColor: 'rgba(251, 191, 36, 0.1)', padding: 8, borderRadius: 8, marginBottom: 8 },
  reasoning: { fontSize: 12, color: '#fbbf24', marginLeft: 6, flex: 1, lineHeight: 16 },
  travelInfo: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  travelTime: { fontSize: 12, color: '#9ca3af', marginLeft: 4 },
  proTipBox: { backgroundColor: 'rgba(139, 92, 246, 0.15)', padding: 8, borderRadius: 8, borderLeftWidth: 3, borderLeftColor: '#8b5cf6' },
  proTip: { fontSize: 11, color: '#c4b5fd', fontStyle: 'italic' },
  loadingContainer: { padding: 32, alignItems: 'center' },
  loadingText: { marginTop: 12, fontSize: 14, color: '#9ca3af' },
  errorContainer: { padding: 32, alignItems: 'center' },
  errorText: { marginTop: 12, fontSize: 14, color: '#ef4444', textAlign: 'center' },
});
