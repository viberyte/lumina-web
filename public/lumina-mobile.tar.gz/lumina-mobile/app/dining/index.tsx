import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  View, Text, ScrollView, TouchableOpacity, StyleSheet, 
  Image, Dimensions, Animated, Platform, TextInput
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import colors from '../../constants/colors';
import luminaApi from '../../services/lumina';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const CARD_WIDTH = SCREEN_WIDTH * 0.42;

const CUISINE_CATEGORIES = [
  { emoji: '🍝', name: 'Italian', key: 'italian', gradient: ['#E63946', '#F4A261'] },
  { emoji: '🍣', name: 'Sushi', key: 'sushi', gradient: ['#2D6A4F', '#40916C'] },
  { emoji: '🌮', name: 'Mexican', key: 'mexican', gradient: ['#F77F00', '#FCBF49'] },
  { emoji: '🥩', name: 'Steakhouse', key: 'steakhouse', gradient: ['#6D3A0A', '#A44A3F'] },
  { emoji: '🥂', name: 'Brunch', key: 'brunch', gradient: ['#F9C74F', '#F8961E'] },
  { emoji: '🍔', name: 'American', key: 'american', gradient: ['#3D5A80', '#98C1D9'] },
  { emoji: '🥗', name: 'Healthy', key: 'healthy', gradient: ['#2D6A4F', '#95D5B2'] },
  { emoji: '🌶️', name: 'Latin', key: 'latin', gradient: ['#D62828', '#F77F00'] },
  { emoji: '🥘', name: 'Mediterranean', key: 'mediterranean', gradient: ['#1D3557', '#457B9D'] },
  { emoji: '🍜', name: 'Asian', key: 'asian', gradient: ['#6B2737', '#C44536'] },
  { emoji: '🍕', name: 'Pizza', key: 'pizza', gradient: ['#BC4749', '#F2E8CF'] },
  { emoji: '🦞', name: 'Seafood', key: 'seafood', gradient: ['#003566', '#0077B6'] },
];

const DINING_ROWS = [
  { title: '🔥 Trending Dining', filter: 'trending', sort: 'viberyte_score' },
  { title: '💎 Upscale Dining', filter: 'upscale', sort: 'rating' },
  { title: '❤️ Date Night', filter: 'date-night', sort: 'rating' },
  { title: '👨‍👩‍👧‍👦 Group Friendly', filter: 'group', sort: 'rating' },
  { title: '🌟 Highly Rated', filter: 'top-rated', sort: 'rating' },
];

export default function DiningScreen() {
  const router = useRouter();
  const scrollY = useRef(new Animated.Value(0)).current;
  
  const [venues, setVenues] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchVenues();
  }, []);

  const fetchVenues = async () => {
    try {
      setLoading(true);
      const data = await luminaApi.getVenues('Manhattan');
      const diningVenues = data.filter((v: any) => 
        v.category === 'dining' || v.category === 'restaurant' || v.cuisine_type
      );
      setVenues(diningVenues);
    } catch (error) {
      console.error('Error fetching venues:', error);
    } finally {
      setLoading(false);
    }
  };

  // Build rows for each cuisine
  const cuisineRows = useMemo(() => {
    return CUISINE_CATEGORIES.map(cat => ({
      ...cat,
      data: venues
        .filter(v => 
          v.cuisine_type?.toLowerCase().includes(cat.key) ||
          v.name?.toLowerCase().includes(cat.key)
        )
        .sort((a, b) => (b.rating || 0) - (a.rating || 0))
        .slice(0, 15)
    })).filter(row => row.data.length > 0);
  }, [venues]);

  // Featured rows
  const featuredRows = useMemo(() => {
    return DINING_ROWS.map(row => {
      let filtered = [...venues];
      
      switch (row.filter) {
        case 'trending':
          filtered = filtered.sort((a, b) => (b.viberyte_score || 0) - (a.viberyte_score || 0));
          break;
        case 'upscale':
          filtered = filtered.filter(v => v.price_level >= 3 || v.vibe_tags?.includes('upscale'));
          break;
        case 'date-night':
          filtered = filtered.filter(v => 
            v.vibe_tags?.includes('date-night') || 
            v.vibe_tags?.includes('romantic') ||
            v.vibe_tags?.includes('intimate')
          );
          break;
        case 'group':
          filtered = filtered.filter(v => 
            v.vibe_tags?.includes('group') || 
            v.vibe_tags?.includes('lively')
          );
          break;
        case 'top-rated':
          filtered = filtered.filter(v => (v.rating || 0) >= 4.5);
          break;
      }
      
      return { ...row, data: filtered.slice(0, 15) };
    }).filter(row => row.data.length > 0);
  }, [venues]);

  // Search results
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    return venues.filter(v => 
      v.name?.toLowerCase().includes(query) ||
      v.cuisine_type?.toLowerCase().includes(query) ||
      v.neighborhood?.toLowerCase().includes(query)
    ).slice(0, 20);
  }, [venues, searchQuery]);

  // Parallax header
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [160, 100],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 60],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });

  // Render venue card
  const renderVenueCard = (venue: any, index: number) => (
    <TouchableOpacity
      key={venue.id}
      style={styles.venueCard}
      onPress={() => {
        if (Platform.OS === 'ios') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        router.push(`/venue/${venue.id}`);
      }}
      activeOpacity={0.9}
    >
      <Image
        source={{ uri: venue.professional_photo_url || venue.image_url || 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4' }}
        style={styles.venueImage}
      />
      <LinearGradient 
        colors={['transparent', 'rgba(0,0,0,0.9)']} 
        style={styles.venueGradient} 
      />
      <View style={styles.venueInfo}>
        <Text style={styles.venueName} numberOfLines={1}>{venue.name}</Text>
        <Text style={styles.venueNeighborhood} numberOfLines={1}>
          {venue.cuisine_type || venue.neighborhood}
        </Text>
        <View style={styles.venueRating}>
          <Ionicons name="star" size={12} color={colors.amber[500]} />
          <Text style={styles.venueRatingText}>{venue.rating?.toFixed(1) || '4.5'}</Text>
          {venue.price_level && (
            <Text style={styles.venuePrice}>{'$'.repeat(venue.price_level)}</Text>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );

  // Render cuisine category tile
  const renderCuisineTile = (cat: typeof CUISINE_CATEGORIES[0], index: number) => (
    <TouchableOpacity
      key={cat.key}
      style={styles.cuisineTile}
      onPress={() => {
        if (Platform.OS === 'ios') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        router.push(`/dining/${cat.key}`);
      }}
      activeOpacity={0.8}
    >
      <LinearGradient
        colors={cat.gradient as any}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.cuisineGradient}
      >
        <Text style={styles.cuisineEmoji}>{cat.emoji}</Text>
        <Text style={styles.cuisineName}>{cat.name}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );

  // Render row
  const renderRow = (row: { title: string; data: any[] }) => {
    if (row.data.length === 0) return null;
    
    return (
      <View key={row.title} style={styles.rowContainer}>
        <View style={styles.rowHeader}>
          <Text style={styles.rowTitle}>{row.title}</Text>
          <TouchableOpacity>
            <Text style={styles.seeAll}>See All →</Text>
          </TouchableOpacity>
        </View>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          decelerationRate="fast"
          snapToInterval={CARD_WIDTH + 12}
          contentContainerStyle={styles.rowScroll}
        >
          {row.data.map((venue, idx) => renderVenueCard(venue, idx))}
        </ScrollView>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#1a0f0a', '#2d1810', '#1a0f0a']}
        style={StyleSheet.absoluteFill}
      />
      
      {/* Header */}
      <Animated.View style={[styles.header, { height: headerHeight }]}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Ionicons name="arrow-back" size={24} color="#fff" />
        </TouchableOpacity>
        
        <Animated.View style={{ opacity: headerOpacity }}>
          <Text style={styles.headerTitle}>🍽️ Dining</Text>
          <Text style={styles.headerSubtitle}>Explore cuisines from around the world</Text>
        </Animated.View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <Ionicons name="search" size={20} color={colors.gray[400]} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search restaurants..."
            placeholderTextColor={colors.gray[500]}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={20} color={colors.gray[400]} />
            </TouchableOpacity>
          )}
        </View>
      </Animated.View>

      {/* Content */}
      {searchQuery.length > 0 ? (
        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          <Text style={styles.searchResultsTitle}>
            {searchResults.length} results for "{searchQuery}"
          </Text>
          <View style={styles.searchResultsGrid}>
            {searchResults.map((venue, idx) => renderVenueCard(venue, idx))}
          </View>
          <View style={{ height: 100 }} />
        </ScrollView>
      ) : (
        <Animated.ScrollView
          style={styles.content}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { y: scrollY } } }],
            { useNativeDriver: false }
          )}
          scrollEventThrottle={16}
        >
          {/* Cuisine Categories Grid */}
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Browse by Cuisine</Text>
          </View>
          <View style={styles.cuisineGrid}>
            {CUISINE_CATEGORIES.map((cat, idx) => renderCuisineTile(cat, idx))}
          </View>

          {/* Featured Rows */}
          {featuredRows.map(row => renderRow(row))}

          {/* Cuisine Rows */}
          {cuisineRows.slice(0, 5).map(row => (
            <View key={row.key} style={styles.rowContainer}>
              <View style={styles.rowHeader}>
                <Text style={styles.rowTitle}>{row.emoji} {row.name}</Text>
                <TouchableOpacity onPress={() => router.push(`/dining/${row.key}`)}>
                  <Text style={styles.seeAll}>See All →</Text>
                </TouchableOpacity>
              </View>
              <ScrollView 
                horizontal 
                showsHorizontalScrollIndicator={false}
                decelerationRate="fast"
                snapToInterval={CARD_WIDTH + 12}
                contentContainerStyle={styles.rowScroll}
              >
                {row.data.map((venue, idx) => renderVenueCard(venue, idx))}
              </ScrollView>
            </View>
          ))}

          <View style={{ height: 100 }} />
        </Animated.ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a0f0a',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: '800',
    color: '#fff',
    letterSpacing: -0.5,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 15,
    color: colors.gray[400],
    marginBottom: 16,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#fff',
    marginLeft: 10,
  },
  content: {
    flex: 1,
  },
  sectionHeader: {
    paddingHorizontal: 20,
    marginTop: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
  },
  cuisineGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    gap: 10,
    marginBottom: 32,
  },
  cuisineTile: {
    width: (SCREEN_WIDTH - 52) / 3,
    height: 90,
    borderRadius: 16,
    overflow: 'hidden',
  },
  cuisineGradient: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
  },
  cuisineEmoji: {
    fontSize: 28,
    marginBottom: 4,
  },
  cuisineName: {
    fontSize: 12,
    fontWeight: '700',
    color: '#fff',
    textAlign: 'center',
  },
  rowContainer: {
    marginBottom: 28,
  },
  rowHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 14,
  },
  rowTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
  },
  seeAll: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F4A261',
  },
  rowScroll: {
    paddingLeft: 20,
    paddingRight: 8,
    gap: 12,
  },
  venueCard: {
    width: CARD_WIDTH,
    height: CARD_WIDTH * 1.3,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: colors.gray[800],
  },
  venueImage: {
    width: '100%',
    height: '100%',
  },
  venueGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '70%',
  },
  venueInfo: {
    position: 'absolute',
    bottom: 14,
    left: 14,
    right: 14,
  },
  venueName: {
    fontSize: 15,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 3,
  },
  venueNeighborhood: {
    fontSize: 12,
    color: colors.gray[300],
    marginBottom: 6,
  },
  venueRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  venueRatingText: {
    fontSize: 12,
    color: '#fff',
    fontWeight: '600',
  },
  venuePrice: {
    fontSize: 11,
    color: colors.gray[400],
    marginLeft: 6,
  },
  searchResultsTitle: {
    fontSize: 16,
    color: colors.gray[400],
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  searchResultsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    gap: 12,
  },
});
