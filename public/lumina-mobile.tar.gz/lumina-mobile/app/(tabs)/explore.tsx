import React, { useRef, useEffect } from 'react';
import { 
  View, Text, StyleSheet, TouchableOpacity, Animated, 
  Dimensions, Platform, ScrollView
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { BlurView } from 'expo-blur';
import colors from '../../constants/colors';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

// Animated Category Tile Component
const CategoryTile = ({ 
  title, 
  emoji, 
  subtitle, 
  gradient, 
  onPress, 
  delay = 0 
}: {
  title: string;
  emoji: string;
  subtitle: string;
  gradient: string[];
  onPress: () => void;
  delay?: number;
}) => {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 400,
        delay,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 400,
        delay,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handlePressIn = () => {
    Animated.spring(scaleAnim, {
      toValue: 0.96,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      friction: 3,
      tension: 40,
      useNativeDriver: true,
    }).start();
  };

  const handlePress = () => {
    if (Platform.OS === 'ios') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    onPress();
  };

  return (
    <Animated.View
      style={[
        styles.tileWrapper,
        {
          opacity: fadeAnim,
          transform: [
            { translateY: slideAnim },
            { scale: scaleAnim }
          ],
        },
      ]}
    >
      <TouchableOpacity
        onPress={handlePress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        activeOpacity={1}
        style={styles.tileTouch}
      >
        <LinearGradient
          colors={gradient as any}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.tile}
        >
          <View style={styles.tileGlow} />
          <Text style={styles.tileEmoji}>{emoji}</Text>
          <Text style={styles.tileTitle}>{title}</Text>
          <Text style={styles.tileSubtitle}>{subtitle}</Text>
          <View style={styles.tileArrow}>
            <Ionicons name="arrow-forward" size={20} color="rgba(255,255,255,0.8)" />
          </View>
        </LinearGradient>
      </TouchableOpacity>
    </Animated.View>
  );
};

export default function ExploreScreen() {
  const router = useRouter();
  const headerFade = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(headerFade, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, []);

  const categories = [
    {
      title: 'Dining',
      emoji: '🍽️',
      subtitle: 'Italian, Sushi, Brunch & more',
      gradient: ['#FF6B35', '#F7931A', '#FFB347'],
      route: '/dining',
    },
    {
      title: 'Nightlife',
      emoji: '🌃',
      subtitle: 'Lounges, Clubs, Rooftops',
      gradient: ['#7B2CBF', '#9D4EDD', '#C77DFF'],
      route: '/nightlife',
    },
    {
      title: 'Events',
      emoji: '🎉',
      subtitle: 'Afrobeats, Latin, EDM & more',
      gradient: ['#E63946', '#F4A261', '#E76F51'],
      route: '/events',
    },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#0a0a0f', '#121218', '#0a0a0f']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Header */}
        <Animated.View style={[styles.header, { opacity: headerFade }]}>
          <Text style={styles.headerTitle}>Explore</Text>
          <Text style={styles.headerSubtitle}>Discover NYC's finest spots</Text>
        </Animated.View>

        {/* Category Tiles */}
        <View style={styles.tilesContainer}>
          {categories.map((cat, index) => (
            <CategoryTile
              key={cat.title}
              title={cat.title}
              emoji={cat.emoji}
              subtitle={cat.subtitle}
              gradient={cat.gradient}
              delay={index * 100}
              onPress={() => router.push(cat.route as any)}
            />
          ))}
        </View>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>4,096+</Text>
            <Text style={styles.statLabel}>Venues</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>6</Text>
            <Text style={styles.statLabel}>Cities</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>3,850+</Text>
            <Text style={styles.statLabel}>Events</Text>
          </View>
        </View>

        {/* Bottom Tagline */}
        <View style={styles.taglineContainer}>
          <Text style={styles.tagline}>Curated by Lumina AI ✨</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0f',
  },
  scrollContent: {
    paddingBottom: 100,
  },
  header: {
    paddingTop: 70,
    paddingHorizontal: 24,
    marginBottom: 32,
  },
  headerTitle: {
    fontSize: 42,
    fontWeight: '800',
    color: '#fff',
    letterSpacing: -1,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 17,
    color: colors.gray[400],
    fontWeight: '500',
  },
  tilesContainer: {
    paddingHorizontal: 20,
    gap: 16,
  },
  tileWrapper: {
    width: '100%',
  },
  tileTouch: {
    borderRadius: 24,
    overflow: 'hidden',
  },
  tile: {
    width: '100%',
    height: SCREEN_HEIGHT * 0.18,
    borderRadius: 24,
    padding: 24,
    justifyContent: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  tileGlow: {
    position: 'absolute',
    top: -50,
    right: -50,
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  tileEmoji: {
    fontSize: 48,
    marginBottom: 12,
  },
  tileTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#fff',
    letterSpacing: -0.5,
    marginBottom: 4,
  },
  tileSubtitle: {
    fontSize: 15,
    color: 'rgba(255,255,255,0.85)',
    fontWeight: '500',
  },
  tileArrow: {
    position: 'absolute',
    right: 24,
    top: '50%',
    marginTop: -10,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    marginTop: 40,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: '800',
    color: '#fff',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 13,
    color: colors.gray[400],
    fontWeight: '500',
  },
  taglineContainer: {
    alignItems: 'center',
    marginTop: 40,
  },
  tagline: {
    fontSize: 14,
    color: colors.gray[500],
    fontWeight: '500',
  },
});
