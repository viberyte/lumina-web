import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Dimensions,
  Image,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { colors, typography, spacing } from '../../theme';
import { glassStyles } from '../../theme/vibeGradients';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const API_BASE = 'https://lumina.viberyte.com';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  venues?: any[];
  events?: any[];
  planExplanation?: string;
  timestamp: Date;
  isTyping?: boolean;
}

export default function ChatScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const scrollViewRef = useRef<ScrollView>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [userName, setUserName] = useState('');
  const [userCity, setUserCity] = useState('Manhattan');
  const [sessionContext, setSessionContext] = useState<any>({});
  
  // Animated glow pulse
  const glowAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    loadProfile();
    addWelcomeMessage();
    startGlowAnimation();
  }, []);

  const startGlowAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(glowAnim, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  const loadProfile = async () => {
    try {
      const profile = await AsyncStorage.getItem('@lumina_profile');
      if (profile) {
        const data = JSON.parse(profile);
        setUserName(data.name || '');
        setUserCity(data.city || 'Manhattan');
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  };

  const addWelcomeMessage = () => {
    const welcomeMsg: Message = {
      id: '0',
      role: 'assistant',
      content: `Hey${userName ? ` ${userName}` : ''}! 👋\n\nI'm Lumina, your AI nightlife concierge. I can help you:\n\n• Plan the perfect evening\n• Find events by music genre\n• Discover hidden gems\n• Get personalized recommendations\n\nWhat are you in the mood for?`,
      timestamp: new Date(),
    };
    setMessages([welcomeMsg]);
  };

  const quickPrompts = [
    { text: 'Plan my night', icon: 'sparkles' },
    { text: 'Afrobeats events tonight', icon: 'musical-notes' },
    { text: 'Date night dinner', icon: 'heart' },
    { text: 'Rooftop lounges', icon: 'wine' },
  ];

  const handleSend = async () => {
    if (!inputText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputText.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    const typingMsg: Message = {
      id: 'typing',
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isTyping: true,
    };
    setMessages(prev => [...prev, typingMsg]);

    try {
      const conversationHistory = messages
        .slice(-6)
        .map(m => ({
          role: m.role,
          content: m.content
        }));
      
      conversationHistory.push({
        role: 'user',
        content: userMessage.content
      });

      const chatResponse = await fetch(`${API_BASE}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: conversationHistory,
          sessionContext: sessionContext
        }),
      });

      const chatData = await chatResponse.json();
      console.log('💬 Chat response:', chatData);

      setMessages(prev => prev.filter(m => m.id !== 'typing'));

      if (chatData.extractedContext) {
        setSessionContext(prev => {
          const merged = { ...prev };
          Object.keys(chatData.extractedContext).forEach(key => {
            const newValue = chatData.extractedContext[key];
            if (newValue !== null && newValue !== undefined) {
              merged[key] = newValue;
            }
          });
          console.log('🧠 Updated session context:', merged);
          return merged;
        });
      }

      if (chatData.action === 'conversational') {
        const assistantMsg: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: chatData.response,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, assistantMsg]);
        setIsLoading(false);
        return;
      }

      if (chatData.action === 'clarify') {
        const clarifyMsg: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: chatData.response,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, clarifyMsg]);
        setIsLoading(false);
        return;
      }

      if (chatData.action === 'trigger_planning') {
        const ackMsg: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: chatData.response,
          timestamp: new Date(),
        };
        setMessages(prev => [...prev, ackMsg]);

        const finalContext = { ...sessionContext };
        if (chatData.extractedContext) {
          Object.keys(chatData.extractedContext).forEach(key => {
            const newValue = chatData.extractedContext[key];
            if (newValue !== null && newValue !== undefined) {
              finalContext[key] = newValue;
            }
          });
        }

        console.log('🎯 Planning with context:', finalContext);

        const planResponse = await fetch(`${API_BASE}/api/plan-evening`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            city: userCity,
            persona: finalContext.persona || 'vibing',
            primaryChoice: finalContext.primaryChoice || 'dinner',
            time: finalContext.time || 'night',
            groupSize: finalContext.groupSize || 2,
            musicPreferences: finalContext.musicPreferences || [],
            spendingVibe: finalContext.occasion === 'special-occasion' ? 'celebration' : 'nice_night',
            travelMode: 'rideshare',
            duration: 'normal',
            occasion: finalContext.occasion,
            energyLevel: finalContext.energyLevel,
            dressCode: finalContext.dressCode,
            referenceVenue: finalContext.referenceVenue,
          }),
        });

        const planData = await planResponse.json();
        console.log('📋 Plan response:', planData);

        if ((planData.venues && planData.venues.length > 0) || (planData.events && planData.events.length > 0)) {
          const resultsMsg: Message = {
            id: Date.now().toString(),
            role: 'assistant',
            content: planData.explanation || 'Here are my recommendations:',
            venues: planData.venues || [],
            events: planData.events || [],
            planExplanation: planData.explanation,
            timestamp: new Date(),
          };
          setMessages(prev => [...prev, resultsMsg]);
        } else {
          const noResultsMsg: Message = {
            id: Date.now().toString(),
            role: 'assistant',
            content: "I couldn't find matches for that. Try being more specific or asking for something else!",
            timestamp: new Date(),
          };
          setMessages(prev => [...prev, noResultsMsg]);
        }
      }

    } catch (error) {
      console.error('❌ Chat error:', error);
      setMessages(prev => prev.filter(m => m.id !== 'typing'));
      
      const errorMsg: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: "Sorry, I'm having trouble connecting. Can you try again?",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPrompt = (text: string) => {
    setInputText(text);
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const glowOpacity = glowAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0.3, 1],
  });

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientEnd]}
      style={styles.container}
    >
      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        {/* Premium Header with Logo */}
        <View style={[styles.header, { paddingTop: insets.top + spacing.md }]}>
          <View style={[styles.headerContent, glassStyles.liquid]}>
            <View style={styles.logoContainer}>
              <Animated.View style={[styles.logoGlow, { opacity: glowOpacity }]} />
              <Image
                source={require('../../assets/images/lumina-logo.png')}
                style={styles.logo}
                resizeMode="contain"
              />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>Lumina AI</Text>
              <View style={styles.statusRow}>
                <View style={styles.onlineDot} />
                <Text style={styles.headerSubtitle}>Online</Text>
              </View>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.profileButton, glassStyles.liquid]}
            onPress={() => router.push('/profile')}
          >
            <Ionicons name="person-outline" size={20} color={colors.white} />
          </TouchableOpacity>
        </View>

        {/* Messages */}
        <ScrollView
          ref={scrollViewRef}
          style={styles.messagesContainer}
          contentContainerStyle={styles.messagesContent}
          showsVerticalScrollIndicator={false}
        >
          {messages.length === 1 && (
            <View style={styles.quickPromptsContainer}>
              <Text style={styles.quickPromptsTitle}>Quick actions:</Text>
              <View style={styles.quickPrompts}>
                {quickPrompts.map((prompt, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[styles.quickPrompt, glassStyles.liquid]}
                    onPress={() => handleQuickPrompt(prompt.text)}
                  >
                    <Ionicons name={prompt.icon as any} size={16} color={colors.violet[400]} />
                    <Text style={styles.quickPromptText}>{prompt.text}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {messages.map((message, index) => (
            <View
              key={message.id}
              style={[
                styles.messageBubble,
                message.role === 'user' ? styles.userBubble : styles.assistantBubble,
              ]}
            >
              {message.role === 'assistant' && (
                <View style={styles.assistantAvatar}>
                  <Image
                    source={require('../../assets/images/lumina-logo.png')}
                    style={styles.miniLogo}
                    resizeMode="contain"
                  />
                </View>
              )}

              <View
                style={[
                  styles.bubbleContent,
                  message.role === 'user' && styles.userBubbleContent,
                ]}
              >
                {message.isTyping ? (
                  <View style={styles.typingIndicator}>
                    <View style={styles.typingDot} />
                    <View style={[styles.typingDot, styles.typingDotDelay1]} />
                    <View style={[styles.typingDot, styles.typingDotDelay2]} />
                  </View>
                ) : (
                  <>
                    <Text
                      style={[
                        styles.messageText,
                        message.role === 'user' && styles.userMessageText,
                      ]}
                    >
                      {message.content}
                    </Text>

                    {(message.venues?.length > 0 || message.events?.length > 0) && message.planExplanation && (
                      <View style={styles.planSummary}>
                        <Text style={styles.planSummaryText}>{message.planExplanation}</Text>
                      </View>
                    )}

                    {message.venues && message.venues.length > 0 && (
                      <ScrollView
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        style={styles.cardsScroll}
                        contentContainerStyle={styles.cardsScrollContent}
                      >
                        {message.venues.map((venue: any, idx: number) => (
                          <TouchableOpacity
                            key={idx}
                            style={styles.cardWrapper}
                            onPress={() => router.push(`/venue/${venue.id}`)}
                          >
                            <View style={[styles.card, glassStyles.liquid]}>
                              {venue.image_url && (
                                <Image
                                  source={{ uri: venue.image_url }}
                                  style={styles.cardImage}
                                />
                              )}
                              <View style={styles.cardNumber}>
                                <Text style={styles.cardNumberText}>{idx + 1}</Text>
                              </View>
                              <View style={styles.cardContent}>
                                <Text style={styles.cardName} numberOfLines={1}>
                                  {venue.name}
                                </Text>
                                <Text style={styles.cardCategory}>{venue.category}</Text>
                                <View style={styles.cardMeta}>
                                  {venue.rating && (
                                    <View style={styles.cardRating}>
                                      <Ionicons name="star" size={12} color={colors.yellow[500]} />
                                      <Text style={styles.cardRatingText}>{venue.rating.toFixed(1)}</Text>
                                    </View>
                                  )}
                                  {venue.distance && (
                                    <View style={styles.cardDistance}>
                                      <Ionicons name="location" size={12} color={colors.violet[400]} />
                                      <Text style={styles.cardDistanceText}>{venue.distance}</Text>
                                    </View>
                                  )}
                                </View>
                                {venue.ai_reasoning && (
                                  <Text style={styles.cardReason} numberOfLines={2}>
                                    {venue.ai_reasoning}
                                  </Text>
                                )}
                              </View>
                            </View>
                          </TouchableOpacity>
                        ))}
                      </ScrollView>
                    )}

                    {message.events && message.events.length > 0 && (
                      <ScrollView
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        style={styles.cardsScroll}
                        contentContainerStyle={styles.cardsScrollContent}
                      >
                        {message.events.map((event: any, idx: number) => (
                          <TouchableOpacity
                            key={idx}
                            style={styles.cardWrapper}
                            onPress={() => router.push(`/event/${event.id}`)}
                          >
                            <View style={[styles.card, styles.eventCard, glassStyles.liquid]}>
                              {event.image_url && (
                                <Image
                                  source={{ uri: event.image_url }}
                                  style={styles.cardImage}
                                />
                              )}
                              <View style={[styles.cardNumber, styles.eventCardNumber]}>
                                <Text style={styles.cardNumberText}>{idx + 1}</Text>
                              </View>
                              <View style={styles.cardContent}>
                                <Text style={styles.cardName} numberOfLines={1}>
                                  {event.title}
                                </Text>
                                <Text style={styles.cardCategory}>{event.genre || 'Event'}</Text>
                                <View style={styles.cardMeta}>
                                  {event.date && (
                                    <View style={styles.eventDate}>
                                      <Ionicons name="calendar" size={12} color={colors.orange[400]} />
                                      <Text style={styles.eventDateText}>
                                        {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                                      </Text>
                                    </View>
                                  )}
                                  {event.venue_name && (
                                    <View style={styles.cardDistance}>
                                      <Ionicons name="location" size={12} color={colors.violet[400]} />
                                      <Text style={styles.cardDistanceText}>{event.venue_name}</Text>
                                    </View>
                                  )}
                                </View>
                              </View>
                            </View>
                          </TouchableOpacity>
                        ))}
                      </ScrollView>
                    )}
                  </>
                )}
              </View>
            </View>
          ))}
        </ScrollView>

        {/* Input */}
        <View style={[styles.inputContainer, { paddingBottom: insets.bottom + spacing.sm }]}>
          <View style={[styles.input, glassStyles.matte]}>
            <TextInput
              style={styles.textInput}
              placeholder="Ask Lumina anything..."
              placeholderTextColor={colors.zinc[500]}
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
              editable={!isLoading}
            />
            <TouchableOpacity
              style={[
                styles.sendButton,
                (!inputText.trim() || isLoading) && styles.sendButtonDisabled,
              ]}
              onPress={handleSend}
              disabled={!inputText.trim() || isLoading}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color={colors.white} />
              ) : (
                <LinearGradient
                  colors={[colors.violet[600], colors.violet[700]]}
                  style={styles.sendButtonGradient}
                >
                  <Ionicons name="arrow-up" size={20} color={colors.white} />
                </LinearGradient>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  keyboardView: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    flex: 1,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
  },
  logoContainer: {
    position: 'relative',
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoGlow: {
    position: 'absolute',
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: colors.violet[500],
    opacity: 0.3,
  },
  logo: {
    width: 40,
    height: 40,
  },
  headerText: {
    gap: 2,
  },
  headerTitle: {
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.green[500],
  },
  headerSubtitle: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[400],
  },
  profileButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.xl,
  },
  quickPromptsContainer: {
    marginBottom: spacing.lg,
  },
  quickPromptsTitle: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[500],
    marginBottom: spacing.sm,
  },
  quickPrompts: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  quickPrompt: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
  },
  quickPromptText: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    fontWeight: '500',
  },
  messageBubble: {
    marginBottom: spacing.md,
    flexDirection: 'row',
    gap: spacing.sm,
  },
  userBubble: {
    justifyContent: 'flex-end',
  },
  assistantBubble: {
    justifyContent: 'flex-start',
  },
  assistantAvatar: {
    marginTop: spacing.xs,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.zinc[800],
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  miniLogo: {
    width: 24,
    height: 24,
  },
  bubbleContent: {
    maxWidth: '85%',
    backgroundColor: colors.zinc[800],
    borderRadius: 16,
    padding: spacing.md,
  },
  userBubbleContent: {
    backgroundColor: colors.violet[600],
    borderRadius: 16,
    borderBottomRightRadius: 4,
  },
  messageText: {
    fontSize: typography.sizes.md,
    color: colors.white,
    lineHeight: 22,
  },
  userMessageText: {
    color: colors.white,
  },
  typingIndicator: {
    flexDirection: 'row',
    gap: spacing.xs,
    paddingVertical: spacing.xs,
  },
  typingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.violet[400],
  },
  typingDotDelay1: {
    opacity: 0.6,
  },
  typingDotDelay2: {
    opacity: 0.3,
  },
  planSummary: {
    marginTop: spacing.md,
    marginBottom: spacing.sm,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.zinc[700],
  },
  planSummaryText: {
    fontSize: typography.sizes.sm,
    color: colors.violet[300],
    fontWeight: '600',
    fontStyle: 'italic',
  },
  cardsScroll: {
    marginTop: spacing.md,
  },
  cardsScrollContent: {
    gap: spacing.sm,
  },
  cardWrapper: {
    width: SCREEN_WIDTH * 0.7,
  },
  card: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  eventCard: {
    borderColor: colors.orange[500] + '30',
  },
  cardImage: {
    width: '100%',
    height: 140,
    backgroundColor: colors.zinc[800],
  },
  cardNumber: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.violet[500],
    justifyContent: 'center',
    alignItems: 'center',
  },
  eventCardNumber: {
    backgroundColor: colors.orange[500],
  },
  cardNumberText: {
    fontSize: typography.sizes.xs,
    fontWeight: '700',
    color: colors.white,
  },
  cardContent: {
    padding: spacing.md,
    gap: spacing.xs,
  },
  cardName: {
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
  },
  cardCategory: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[400],
    textTransform: 'uppercase',
    fontWeight: '600',
  },
  cardMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.xs,
  },
  cardRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  cardRatingText: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    fontWeight: '600',
  },
  cardDistance: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  cardDistanceText: {
    fontSize: typography.sizes.xs,
    color: colors.violet[400],
    fontWeight: '500',
  },
  eventDate: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  eventDateText: {
    fontSize: typography.sizes.xs,
    color: colors.orange[400],
    fontWeight: '600',
  },
  cardReason: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[300],
    lineHeight: 18,
    fontStyle: 'italic',
    marginTop: spacing.xs,
  },
  inputContainer: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
  },
  input: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
  },
  textInput: {
    flex: 1,
    fontSize: typography.sizes.md,
    color: colors.white,
    maxHeight: 100,
    paddingVertical: spacing.xs,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    overflow: 'hidden',
  },
  sendButtonDisabled: {
    opacity: 0.5,
  },
  sendButtonGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
