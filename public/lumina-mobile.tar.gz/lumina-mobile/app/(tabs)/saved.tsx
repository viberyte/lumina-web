import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing } from '../../theme';
import favoritesService, { FavoriteVenue } from '../../services/favorites';

export default function SavedScreen() {
  const router = useRouter();
  const [favorites, setFavorites] = useState<FavoriteVenue[]>([]);

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    const favs = await favoritesService.getFavorites();
    setFavorites(favs);
  };

  const removeFavorite = async (venueId: string) => {
    await favoritesService.removeFavorite(venueId);
    loadFavorites();
  };

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientEnd]}
      style={styles.container}
    >
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Saved Venues</Text>
        <Text style={styles.headerSubtitle}>{favorites.length} spots saved</Text>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {favorites.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="heart-outline" size={80} color={colors.zinc[700]} />
            <Text style={styles.emptyTitle}>No saved venues yet</Text>
            <Text style={styles.emptyText}>
              Start exploring and save your favorite spots for later
            </Text>
          </View>
        ) : (
          <View style={styles.venueGrid}>
            {favorites.map((venue) => (
              <TouchableOpacity
                key={venue.id}
                style={styles.venueCard}
                onPress={() => router.push({
                  pathname: '/venue/[id]',
                  params: { id: venue.id, venue: JSON.stringify(venue) },
                })}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#FFFFFF', '#F4F4F4']}
                  style={styles.cardGradient}
                >
                  {venue.professional_photo_url && (
                    <Image
                      source={{ uri: venue.professional_photo_url }}
                      style={styles.venueImage}
                      resizeMode="cover"
                    />
                  )}

                  <TouchableOpacity
                    style={styles.heartButton}
                    onPress={(e) => {
                      e.stopPropagation();
                      removeFavorite(venue.id);
                    }}
                  >
                    <Ionicons name="heart" size={20} color="#EF4444" />
                  </TouchableOpacity>

                  <View style={styles.venueInfo}>
                    <Text style={styles.venueName} numberOfLines={1}>
                      {venue.name}
                    </Text>
                    {venue.neighborhood && (
                      <View style={styles.locationRow}>
                        <Ionicons name="location" size={12} color="#52525B" />
                        <Text style={styles.neighborhood}>{venue.neighborhood}</Text>
                      </View>
                    )}
                  </View>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: spacing.lg,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.zinc[900],
  },
  headerTitle: {
    fontSize: typography.sizes['2xl'],
    fontWeight: '600',
    color: colors.white,
    marginBottom: spacing.xs,
  },
  headerSubtitle: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[500],
  },
  scrollContent: {
    padding: spacing.lg,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing['3xl'],
  },
  emptyTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: '600',
    color: colors.white,
    marginTop: spacing.xl,
    marginBottom: spacing.sm,
  },
  emptyText: {
    fontSize: typography.sizes.base,
    color: colors.zinc[500],
    textAlign: 'center',
    paddingHorizontal: spacing.xl,
  },
  venueGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  venueCard: {
    width: '48%',
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  cardGradient: {
    borderRadius: 16,
  },
  venueImage: {
    width: '100%',
    height: 140,
    backgroundColor: colors.zinc[200],
  },
  heartButton: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  venueInfo: {
    padding: spacing.md,
  },
  venueName: {
    fontSize: typography.sizes.base,
    fontWeight: '600',
    color: '#000000',
    marginBottom: spacing.xs,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  neighborhood: {
    fontSize: typography.sizes.xs,
    color: '#52525B',
  },
});
