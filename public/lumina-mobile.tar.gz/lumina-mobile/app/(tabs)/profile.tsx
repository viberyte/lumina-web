import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Switch,
  Image,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import { colors, typography, spacing } from '../../theme';
import { glassStyles } from '../../theme/vibeGradients';
import favoritesService from '../../services/favorites';

const VIBES = [
  { id: 'upscale', emoji: '✨', label: 'Upscale' },
  { id: 'high-energy', emoji: '⚡', label: 'High Energy' },
  { id: 'rooftop', emoji: '🌃', label: 'Rooftops' },
  { id: 'chill', emoji: '🍷', label: 'Chill' },
  { id: 'date-night', emoji: '❤️', label: 'Date Night' },
  { id: 'brunch', emoji: '🥂', label: 'Brunch' },
];

const MUSIC_GENRES = [
  { id: 'afrobeats', emoji: '🎵', label: 'Afrobeats' },
  { id: 'hip-hop', emoji: '🎤', label: 'Hip-Hop' },
  { id: 'edm', emoji: '🎧', label: 'EDM/House' },
  { id: 'latin', emoji: '💃', label: 'Latin' },
  { id: 'r&b', emoji: '🎹', label: 'R&B' },
  { id: 'live-music', emoji: '🎸', label: 'Live Music' },
];

const NIGHTLIFE_STYLES = [
  { id: 'upscale', label: 'Always Upscale', icon: 'diamond-outline' },
  { id: 'mixed', label: 'Mix of Options', icon: 'shuffle-outline' },
  { id: 'casual', label: 'Casual & Easygoing', icon: 'sunny-outline' },
];

const TRAVEL_MODES = [
  { id: 'walking', emoji: '🚶', label: 'Walking' },
  { id: 'subway', emoji: '🚇', label: 'Subway' },
  { id: 'rideshare', emoji: '🚕', label: 'Rideshare' },
  { id: 'driving', emoji: '🚗', label: 'Driving' },
];

export default function ProfileScreen() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [selectedCity, setSelectedCity] = useState('Manhattan');
  const [selectedVibes, setSelectedVibes] = useState<string[]>([]);
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [nightlifeStyle, setNightlifeStyle] = useState('mixed');
  const [travelMode, setTravelMode] = useState('rideshare');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [eventAlertsEnabled, setEventAlertsEnabled] = useState(true);
  const [editing, setEditing] = useState(false);
  const [savedVenues, setSavedVenues] = useState<any[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  useEffect(() => {
    loadProfile();
    loadSavedVenues();
    loadRecentActivity();
  }, []);

  const loadProfile = async () => {
    try {
      const profile = await AsyncStorage.getItem('@lumina_profile');
      if (profile) {
        const data = JSON.parse(profile);
        setName(data.name || '');
        setEmail(data.email || '');
        setSelectedCity(data.city || 'Manhattan');
        setSelectedVibes(data.vibes || []);
        setSelectedGenres(data.musicGenres || []);
        setNightlifeStyle(data.nightlifeStyle || 'mixed');
        setTravelMode(data.travelMode || 'rideshare');
        setNotificationsEnabled(data.notifications !== false);
        setEventAlertsEnabled(data.eventAlerts !== false);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  };

  const loadSavedVenues = async () => {
    try {
      const favorites = await favoritesService.getFavorites();
      setSavedVenues(favorites);
    } catch (error) {
      console.error('Error loading saved venues:', error);
    }
  };

  const loadRecentActivity = async () => {
    try {
      const activity = await AsyncStorage.getItem('@lumina_recent_activity');
      if (activity) {
        setRecentActivity(JSON.parse(activity));
      }
    } catch (error) {
      console.error('Error loading recent activity:', error);
    }
  };

  const saveProfile = async () => {
    try {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      
      const profile = {
        name,
        email,
        city: selectedCity,
        vibes: selectedVibes,
        musicGenres: selectedGenres,
        nightlifeStyle,
        travelMode,
        notifications: notificationsEnabled,
        eventAlerts: eventAlertsEnabled,
      };
      await AsyncStorage.setItem('@lumina_profile', JSON.stringify(profile));
      setEditing(false);
      console.log('✅ Profile saved');
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  const toggleVibe = async (vibeId: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedVibes(prev =>
      prev.includes(vibeId)
        ? prev.filter(v => v !== vibeId)
        : [...prev, vibeId]
    );
  };

  const toggleGenre = async (genreId: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedGenres(prev =>
      prev.includes(genreId)
        ? prev.filter(g => g !== genreId)
        : [...prev, genreId]
    );
  };

  const handleResetPreferences = async () => {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    
    Alert.alert(
      'Reset Preferences',
      'This will reset your vibes, music preferences, and settings to defaults.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            setSelectedVibes([]);
            setSelectedGenres([]);
            setNightlifeStyle('mixed');
            setTravelMode('rideshare');
            await saveProfile();
          },
        },
      ]
    );
  };

  const handleResetAIMemory = async () => {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    
    Alert.alert(
      'Reset AI Memory',
      'This will clear Lumina\'s conversation context. Your preferences and favorites will be kept.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: async () => {
            await AsyncStorage.removeItem('@lumina_chat_context');
            Alert.alert('Success', 'AI memory has been reset!');
          },
        },
      ]
    );
  };

  const handleDeleteAccount = async () => {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    
    Alert.alert(
      'Delete Account',
      'This will permanently delete all your data including favorites and preferences. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await AsyncStorage.multiRemove([
                '@lumina_profile',
                '@lumina_favorites',
                '@lumina_city_interests',
                '@lumina_recent_activity',
                '@lumina_chat_context',
              ]);
              router.replace('/onboarding');
            } catch (error) {
              console.error('Error deleting account:', error);
            }
          },
        },
      ]
    );
  };

  const removeVenue = async (venueId: number) => {
    await favoritesService.removeFavorite(venueId);
    loadSavedVenues();
  };

  const getInitials = () => {
    if (!name) return '?';
    const parts = name.trim().split(' ');
    if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
    return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
  };

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientEnd]}
      style={styles.container}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Profile</Text>
        <TouchableOpacity
          style={[styles.editButton, editing && styles.editButtonActive]}
          onPress={() => editing ? saveProfile() : setEditing(true)}
        >
          <Ionicons 
            name={editing ? "checkmark" : "pencil"} 
            size={20} 
            color={editing ? colors.white : colors.violet[400]} 
          />
          <Text style={[styles.editButtonText, editing && styles.editButtonTextActive]}>
            {editing ? 'Save' : 'Edit'}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Profile Card with Avatar */}
        <View style={[styles.profileHeader, glassStyles.liquid]}>
          <LinearGradient
            colors={[colors.violet[500], colors.violet[600]]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.avatar}
          >
            <Text style={styles.avatarText}>{getInitials()}</Text>
          </LinearGradient>
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{name || 'Guest User'}</Text>
            <TouchableOpacity 
              style={styles.cityBadge}
              onPress={() => router.push('/city-select-modal')}
            >
              <Ionicons name="location" size={14} color={colors.violet[400]} />
              <Text style={styles.cityText}>{selectedCity}</Text>
              <Ionicons name="chevron-forward" size={14} color={colors.zinc[500]} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Personal Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Name</Text>
              {editing ? (
                <TextInput
                  style={styles.input}
                  value={name}
                  onChangeText={setName}
                  placeholder="Enter your name"
                  placeholderTextColor={colors.zinc[600]}
                />
              ) : (
                <Text style={styles.value}>{name || 'Not set'}</Text>
              )}
            </View>

            <View style={styles.divider} />

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email</Text>
              {editing ? (
                <TextInput
                  style={styles.input}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="Enter your email"
                  placeholderTextColor={colors.zinc[600]}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              ) : (
                <Text style={styles.value}>{email || 'Not set'}</Text>
              )}
            </View>
          </View>
        </View>

        {/* Your Vibes */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Vibes</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            <View style={styles.pillsContainer}>
              {VIBES.map((vibe) => {
                const isSelected = selectedVibes.includes(vibe.id);
                return (
                  <TouchableOpacity
                    key={vibe.id}
                    style={[
                      styles.pill,
                      isSelected && styles.pillActive,
                      !editing && styles.pillDisabled,
                    ]}
                    onPress={() => editing && toggleVibe(vibe.id)}
                    disabled={!editing}
                  >
                    <Text style={styles.pillEmoji}>{vibe.emoji}</Text>
                    <Text style={[styles.pillText, isSelected && styles.pillTextActive]}>
                      {vibe.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        </View>

        {/* Music Preferences */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Favorite Music for Events</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            <View style={styles.pillsContainer}>
              {MUSIC_GENRES.map((genre) => {
                const isSelected = selectedGenres.includes(genre.id);
                return (
                  <TouchableOpacity
                    key={genre.id}
                    style={[
                      styles.pill,
                      isSelected && styles.pillActive,
                      !editing && styles.pillDisabled,
                    ]}
                    onPress={() => editing && toggleGenre(genre.id)}
                    disabled={!editing}
                  >
                    <Text style={styles.pillEmoji}>{genre.emoji}</Text>
                    <Text style={[styles.pillText, isSelected && styles.pillTextActive]}>
                      {genre.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        </View>

        {/* Nightlife Style */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferred Nightlife Style</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            {NIGHTLIFE_STYLES.map((style, index) => (
              <View key={style.id}>
                {index > 0 && <View style={styles.divider} />}
                <TouchableOpacity
                  style={styles.radioRow}
                  onPress={() => editing && setNightlifeStyle(style.id)}
                  disabled={!editing}
                >
                  <Ionicons name={style.icon as any} size={24} color={colors.violet[500]} />
                  <Text style={styles.radioLabel}>{style.label}</Text>
                  <View style={[
                    styles.radio,
                    nightlifeStyle === style.id && styles.radioActive,
                  ]}>
                    {nightlifeStyle === style.id && (
                      <View style={styles.radioInner} />
                    )}
                  </View>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </View>

        {/* Travel Mode */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferred Travel Mode</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            <View style={styles.travelModes}>
              {TRAVEL_MODES.map((mode) => (
                <TouchableOpacity
                  key={mode.id}
                  style={[
                    styles.travelMode,
                    travelMode === mode.id && styles.travelModeActive,
                    !editing && styles.travelModeDisabled,
                  ]}
                  onPress={() => editing && setTravelMode(mode.id)}
                  disabled={!editing}
                >
                  <Text style={styles.travelEmoji}>{mode.emoji}</Text>
                  <Text style={[
                    styles.travelLabel,
                    travelMode === mode.id && styles.travelLabelActive,
                  ]}>
                    {mode.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>

        {/* Saved Venues */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Saved Venues ({savedVenues.length})</Text>
          
          {savedVenues.length === 0 ? (
            <View style={[styles.emptyCard, glassStyles.matte]}>
              <Ionicons name="heart-outline" size={48} color={colors.zinc[700]} />
              <Text style={styles.emptyText}>No saved venues yet</Text>
              <Text style={styles.emptyHint}>Heart venues to save them here</Text>
            </View>
          ) : (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.venuesScroll}
            >
              {savedVenues.slice(0, 10).map((venue) => (
                <TouchableOpacity
                  key={venue.id}
                  style={[styles.venueCard, glassStyles.liquid]}
                  onPress={() => router.push(`/venue/${venue.id}`)}
                >
                  <Image 
                    source={{ uri: venue.professional_photo_url || venue.photo_url }}
                    style={styles.venueImage}
                  />
                  <TouchableOpacity
                    style={styles.venueHeart}
                    onPress={(e) => {
                      e.stopPropagation();
                      removeVenue(venue.id);
                    }}
                  >
                    <Ionicons name="heart" size={16} color={colors.pink[500]} />
                  </TouchableOpacity>
                  <View style={styles.venueCardInfo}>
                    <Text style={styles.venueCardName} numberOfLines={1}>
                      {venue.name}
                    </Text>
                    <Text style={styles.venueCardCategory} numberOfLines={1}>
                      {venue.category}
                    </Text>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}
        </View>

        {/* Recent Activity */}
        {recentActivity.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Recent Activity</Text>
            
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.activityScroll}
            >
              {recentActivity.slice(0, 10).map((item, index) => (
                <View key={index} style={[styles.activityCard, glassStyles.matte]}>
                  <Ionicons name="time-outline" size={20} color={colors.violet[400]} />
                  <Text style={styles.activityText} numberOfLines={2}>
                    {item.action}
                  </Text>
                  <Text style={styles.activityTime}>
                    {new Date(item.timestamp).toLocaleDateString()}
                  </Text>
                </View>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Notifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notifications</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Ionicons name="notifications-outline" size={24} color={colors.violet[500]} />
                <View style={styles.settingText}>
                  <Text style={styles.settingTitle}>Push Notifications</Text>
                  <Text style={styles.settingDescription}>
                    Get notified about new venues
                  </Text>
                </View>
              </View>
              <Switch
                value={notificationsEnabled}
                onValueChange={setNotificationsEnabled}
                trackColor={{ false: colors.zinc[800], true: colors.violet[600] }}
                thumbColor={notificationsEnabled ? colors.violet[400] : colors.zinc[600]}
                disabled={!editing}
              />
            </View>

            <View style={styles.divider} />

            <View style={styles.settingRow}>
              <View style={styles.settingInfo}>
                <Ionicons name="calendar-outline" size={24} color={colors.violet[500]} />
                <View style={styles.settingText}>
                  <Text style={styles.settingTitle}>Event Alerts</Text>
                  <Text style={styles.settingDescription}>
                    Get alerts for upcoming events
                  </Text>
                </View>
              </View>
              <Switch
                value={eventAlertsEnabled}
                onValueChange={setEventAlertsEnabled}
                trackColor={{ false: colors.zinc[800], true: colors.violet[600] }}
                thumbColor={eventAlertsEnabled ? colors.violet[400] : colors.zinc[600]}
                disabled={!editing}
              />
            </View>
          </View>
        </View>

        {/* Subscription & Rewards (Future) */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Subscription & Rewards</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            <View style={styles.subscriptionHeader}>
              <View>
                <Text style={styles.subscriptionTitle}>Current Plan</Text>
                <Text style={styles.subscriptionPlan}>Free</Text>
              </View>
              <View style={styles.comingSoonBadge}>
                <Text style={styles.comingSoonText}>Coming Soon</Text>
              </View>
            </View>
            
            <View style={styles.divider} />
            
            <Text style={styles.subscriptionHint}>
              Vibe+ Premium launching soon with exclusive perks and early event access! 🚀
            </Text>
          </View>
        </View>

        {/* Data & Privacy */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Data & Privacy</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            <TouchableOpacity style={styles.actionRow} onPress={handleResetPreferences}>
              <Ionicons name="refresh-outline" size={24} color={colors.orange[500]} />
              <Text style={styles.actionLabel}>Reset Preferences</Text>
              <Ionicons name="chevron-forward" size={20} color={colors.zinc[500]} />
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity style={styles.actionRow} onPress={handleResetAIMemory}>
              <Ionicons name="sparkles-outline" size={24} color={colors.violet[500]} />
              <Text style={styles.actionLabel}>Reset AI Memory</Text>
              <Ionicons name="chevron-forward" size={20} color={colors.zinc[500]} />
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity style={styles.actionRow} onPress={handleDeleteAccount}>
              <Ionicons name="trash-outline" size={24} color={colors.red[500]} />
              <Text style={[styles.actionLabel, styles.dangerText]}>Delete Account</Text>
              <Ionicons name="chevron-forward" size={20} color={colors.zinc[500]} />
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          
          <View style={[styles.card, glassStyles.matte]}>
            <View style={styles.infoRow}>
              <Text style={styles.label}>Version</Text>
              <Text style={styles.value}>1.0.0</Text>
            </View>
            
            <View style={styles.divider} />
            
            <TouchableOpacity style={styles.infoRow}>
              <Text style={styles.label}>Terms of Service</Text>
              <Ionicons name="chevron-forward" size={20} color={colors.zinc[500]} />
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity style={styles.infoRow}>
              <Text style={styles.label}>Privacy Policy</Text>
              <Ionicons name="chevron-forward" size={20} color={colors.zinc[500]} />
            </TouchableOpacity>
          </View>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.zinc[900],
  },
  headerTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: '300',
    color: colors.white,
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
    backgroundColor: colors.glass.medium,
    borderWidth: 1,
    borderColor: colors.violet[600],
  },
  editButtonActive: {
    backgroundColor: colors.violet[600],
  },
  editButtonText: {
    fontSize: typography.sizes.sm,
    fontWeight: '600',
    color: colors.violet[400],
  },
  editButtonTextActive: {
    color: colors.white,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.lg,
    borderRadius: 16,
    marginBottom: spacing.lg,
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 32,
    fontWeight: '700',
    color: colors.white,
  },
  profileInfo: {
    flex: 1,
    gap: spacing.xs,
  },
  profileName: {
    fontSize: typography.sizes.xl,
    fontWeight: '600',
    color: colors.white,
  },
  cityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    alignSelf: 'flex-start',
  },
  cityText: {
    fontSize: typography.sizes.sm,
    color: colors.violet[400],
    fontWeight: '500',
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    fontSize: typography.sizes.sm,
    fontWeight: '600',
    color: colors.zinc[500],
    marginBottom: spacing.md,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  card: {
    borderRadius: 16,
    padding: spacing.lg,
  },
  emptyCard: {
    borderRadius: 16,
    padding: spacing.xl,
    alignItems: 'center',
    gap: spacing.sm,
  },
  emptyText: {
    fontSize: typography.sizes.md,
    fontWeight: '500',
    color: colors.zinc[400],
  },
  emptyHint: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[600],
    textAlign: 'center',
  },
  inputGroup: {
    gap: spacing.sm,
  },
  label: {
    fontSize: typography.sizes.sm,
    fontWeight: '500',
    color: colors.zinc[400],
  },
  value: {
    fontSize: typography.sizes.md,
    fontWeight: '400',
    color: colors.white,
  },
  input: {
    fontSize: typography.sizes.md,
    fontWeight: '400',
    color: colors.white,
    backgroundColor: colors.zinc[900],
    borderRadius: 8,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.zinc[800],
  },
  divider: {
    height: 1,
    backgroundColor: colors.zinc[800],
    marginVertical: spacing.md,
  },
  pillsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
    backgroundColor: colors.zinc[800],
    borderWidth: 1,
    borderColor: colors.zinc[700],
  },
  pillActive: {
    backgroundColor: colors.violet[600],
    borderColor: colors.violet[500],
  },
  pillDisabled: {
    opacity: 0.7,
  },
  pillEmoji: {
    fontSize: 16,
  },
  pillText: {
    fontSize: typography.sizes.sm,
    fontWeight: '500',
    color: colors.zinc[400],
  },
  pillTextActive: {
    color: colors.white,
  },
  radioRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  radioLabel: {
    flex: 1,
    fontSize: typography.sizes.md,
    color: colors.white,
    fontWeight: '500',
  },
  radio: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.zinc[600],
    justifyContent: 'center',
    alignItems: 'center',
  },
  radioActive: {
    borderColor: colors.violet[500],
  },
  radioInner: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.violet[500],
  },
  travelModes: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  travelMode: {
    flex: 1,
    alignItems: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.md,
    borderRadius: 12,
    backgroundColor: colors.zinc[800],
    borderWidth: 1,
    borderColor: colors.zinc[700],
  },
  travelModeActive: {
    backgroundColor: colors.violet[600],
    borderColor: colors.violet[500],
  },
  travelModeDisabled: {
    opacity: 0.7,
  },
  travelEmoji: {
    fontSize: 24,
  },
  travelLabel: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[400],
    fontWeight: '500',
  },
  travelLabelActive: {
    color: colors.white,
  },
  venuesScroll: {
    gap: spacing.md,
  },
  venueCard: {
    width: 140,
    borderRadius: 12,
    overflow: 'hidden',
  },
  venueImage: {
    width: '100%',
    height: 120,
    backgroundColor: colors.zinc[800],
  },
  venueHeart: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  venueCardInfo: {
    padding: spacing.sm,
    gap: 4,
  },
  venueCardName: {
    fontSize: typography.sizes.sm,
    fontWeight: '600',
    color: colors.white,
  },
  venueCardCategory: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[500],
  },
  activityScroll: {
    gap: spacing.md,
  },
  activityCard: {
    width: 180,
    padding: spacing.md,
    borderRadius: 12,
    gap: spacing.xs,
  },
  activityText: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    lineHeight: 18,
  },
  activityTime: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[500],
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    flex: 1,
  },
  settingText: {
    flex: 1,
    gap: spacing.xs,
  },
  settingTitle: {
    fontSize: typography.sizes.md,
    fontWeight: '500',
    color: colors.white,
  },
  settingDescription: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[500],
  },
  subscriptionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  subscriptionTitle: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
    marginBottom: spacing.xs,
  },
  subscriptionPlan: {
    fontSize: typography.sizes.lg,
    fontWeight: '600',
    color: colors.white,
  },
  comingSoonBadge: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: 12,
    backgroundColor: colors.violet[600] + '30',
  },
  comingSoonText: {
    fontSize: typography.sizes.xs,
    fontWeight: '600',
    color: colors.violet[400],
  },
  subscriptionHint: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[500],
    lineHeight: 20,
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  actionLabel: {
    flex: 1,
    fontSize: typography.sizes.md,
    color: colors.white,
    fontWeight: '500',
  },
  dangerText: {
    color: colors.red[500],
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
