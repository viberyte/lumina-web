import React, { useState, useEffect, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import { colors, typography, spacing } from '../../theme';
import VenueCarousel from '../../components/VenueCarousel';
import EventCarousel from '../../components/EventCarousel';
import luminaApi from '../../services/lumina';

// FIX #2: Move CITY_COORDS outside component (memory optimization)
const CITY_COORDS: Record<string, { lat: number; lon: number }> = {
  'Manhattan': { lat: 40.7831, lon: -73.9712 },
  'Brooklyn': { lat: 40.6782, lon: -73.9442 },
  'Queens': { lat: 40.7282, lon: -73.7949 },
  'Bronx': { lat: 40.8448, lon: -73.8648 },
  'Jersey City': { lat: 40.7178, lon: -74.0431 },
  'Hoboken': { lat: 40.7439, lon: -74.0323 },
  'Washington DC': { lat: 38.9072, lon: -77.0369 },
  'Philadelphia': { lat: 39.9526, lon: -75.1652 },
  'Baltimore': { lat: 39.2904, lon: -76.6122 },
  'Richmond': { lat: 37.5407, lon: -77.4360 },
  'Norfolk': { lat: 36.8508, lon: -76.2859 },
};

const WEATHER_CACHE_KEY = '@lumina_weather_cache';
const WEATHER_CACHE_DURATION = 10 * 60 * 1000; // 10 minutes

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function HomeScreen() {
  const router = useRouter();
  const [userName, setUserName] = useState('');
  const [profileCompleted, setProfileCompleted] = useState(false);
  const [city, setCity] = useState('Manhattan');
  const [allVenues, setAllVenues] = useState<any[]>([]);
  const [allEvents, setAllEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [weather, setWeather] = useState<any>(null);

  // Load profile on mount
  useEffect(() => {
    loadProfile();
  }, []);

  // Reload data when city changes
  useEffect(() => {
    loadHomeData();
    fetchWeatherWithCache();
  }, [city]);

  const loadProfile = async () => {
    try {
      const profile = await AsyncStorage.getItem('@lumina_profile');
      if (profile) {
        const data = JSON.parse(profile);
        setUserName(data.name || '');
        setCity(data.city || 'Manhattan');
        // FIX #6: Check if profile is completed
        setProfileCompleted(Boolean(data.name && data.preferences && data.preferences.length > 0));
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  };

  const loadHomeData = async () => {
    setLoading(true);
    setError('');
    
    try {
      const [venues, events] = await Promise.all([
        luminaApi.getVenuesByCategory(city, ''),
        luminaApi.getEventsByGenre(city, '')
      ]);
      
      setAllVenues(venues);
      setAllEvents(events);
      setLoading(false);
    } catch (error) {
      console.error('Error loading home data:', error);
      setError('Unable to load data. Check your connection.');
      setLoading(false);
    }
  };

  // FIX #4: Weather API caching (10 min cache)
  const fetchWeatherWithCache = async () => {
    try {
      // Check cache first
      const cached = await AsyncStorage.getItem(WEATHER_CACHE_KEY);
      if (cached) {
        const { data, city: cachedCity, timestamp } = JSON.parse(cached);
        const isValid = Date.now() - timestamp < WEATHER_CACHE_DURATION;
        const isSameCity = cachedCity === city;
        
        if (isValid && isSameCity) {
          setWeather(data);
          return;
        }
      }

      // Fetch fresh data
      const coords = CITY_COORDS[city] || CITY_COORDS['Manhattan'];
      const response = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${coords.lat}&longitude=${coords.lon}&current=temperature_2m,precipitation,weather_code&timezone=America/New_York`
      );
      const result = await response.json();
      
      if (result.current) {
        setWeather(result.current);
        // Save to cache
        await AsyncStorage.setItem(WEATHER_CACHE_KEY, JSON.stringify({
          data: result.current,
          city: city,
          timestamp: Date.now()
        }));
      }
    } catch (error) {
      console.error('Error fetching weather:', error);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  // FIX #3: Weather icon helper
  const getWeatherIcon = (code: number | undefined): string => {
    if (!code) return '🌡️';
    if (code === 0) return '☀️';
    if (code <= 3) return '⛅';
    if (code <= 49) return '🌫️';
    if (code <= 69) return '🌧️';
    if (code <= 79) return '🌨️';
    if (code <= 99) return '⛈️';
    return '🌡️';
  };

  const getContextualSubtitle = () => {
    const hour = new Date().getHours();
    const day = new Date().getDay();
    
    // FIX #1: Safe weather access with optional chaining and nullish coalescing
    const isRaining = (weather?.precipitation ?? 0) > 0;
    const temp = weather?.temperature_2m ?? null;
    
    if (isRaining) {
      return "Rainy day — cozy indoor spots recommended ☔";
    }
    
    if (temp !== null && temp > 75 && hour >= 11 && hour < 20) {
      return "Perfect weather for rooftops ☀️";
    }
    
    // Friday night
    if (day === 5 && hour >= 18) {
      return "It's Friday night — nightlife is heating up 🔥";
    }
    
    // Saturday
    if (day === 6) {
      if (hour < 12) return "Perfect morning for brunch spots ☀️";
      if (hour < 18) return "Saturday vibes — rooftops are open 🌃";
      return "Saturday night — the city is alive ✨";
    }
    
    // Sunday brunch
    if (day === 0 && hour >= 10 && hour < 15) {
      return "Sunday Funday — brunch time 🥂";
    }
    
    // Weekday evening
    if (day >= 1 && day <= 4 && hour >= 18) {
      return "Weeknight vibes — cozy lounges recommended 🍷";
    }
    
    // Late night
    if (hour >= 22 || hour < 4) {
      return "Late night energy — clubs are open 🎵";
    }
    
    return "Discover the best spots in the city ✨";
  };

  // MEMOIZED: Tonight's picks with contextual logic
  const tonightsPicks = useMemo(() => {
    const hour = new Date().getHours();
    const day = new Date().getDay();
    
    let filtered = [...allVenues];
    
    // FIX #1: Safe weather access
    if ((weather?.precipitation ?? 0) > 0) {
      filtered = filtered.filter((v: any) => 
        !Array.isArray(v.vibe_tags) || 
        (!v.vibe_tags.includes('rooftop') && !v.vibe_tags.includes('outdoor'))
      );
    }
    
    // Weekend nights → high energy
    if ((day === 5 || day === 6) && hour >= 20) {
      filtered = filtered.filter((v: any) => 
        v.category === 'nightlife' || 
        (Array.isArray(v.vibe_tags) && v.vibe_tags.includes('high-energy'))
      );
    }
    
    // Weekday evenings → chill spots
    if (day >= 1 && day <= 4 && hour >= 17 && hour < 22) {
      filtered = filtered.filter((v: any) => 
        Array.isArray(v.vibe_tags) && 
        (v.vibe_tags.includes('chill') || v.vibe_tags.includes('cozy'))
      );
    }
    
    // Brunch time (Sat/Sun 10am-3pm)
    if ((day === 0 || day === 6) && hour >= 10 && hour < 15) {
      filtered = filtered.filter((v: any) => 
        Array.isArray(v.vibe_tags) && v.vibe_tags.includes('brunch')
      );
    }
    
    // Default: high-rated venues
    return filtered
      .filter((v: any) => (v.rating || 0) >= 4.5)
      .sort((a: any, b: any) => (b.rating || 0) - (a.rating || 0))
      .slice(0, 6);
  }, [allVenues, weather]);

  // MEMOIZED: Trending venues
  const trendingVenues = useMemo(() => {
    return [...allVenues]
      .sort((a: any, b: any) => (b.viberyte_score || 0) - (a.viberyte_score || 0))
      .slice(0, 8);
  }, [allVenues]);

  // MEMOIZED: Upcoming events
  const upcomingEvents = useMemo(() => {
    return allEvents
      .filter((e: any) => {
        if (!e.date) return true;
        try {
          return new Date(e.date) >= new Date();
        } catch {
          return true;
        }
      })
      .slice(0, 5);
  }, [allEvents]);

  // FIX: Quick actions now navigate to Explore with filter
  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'Plan My Night':
        router.push('/(tabs)/chat');
        break;
      case 'Find Dinner':
        router.push('/(tabs)/explore?filter=dining');
        break;
      case 'Nightlife':
        router.push('/(tabs)/explore?filter=nightlife');
        break;
      case 'Events':
        router.push('/(tabs)/explore?filter=events');
        break;
    }
  };

  const quickActions = [
    { icon: 'sparkles', label: 'Plan My Night', color: colors.violet[500] },
    { icon: 'restaurant-outline', label: 'Find Dinner', color: colors.violet[400] },
    { icon: 'wine-outline', label: 'Nightlife', color: colors.violet[600] },
    { icon: 'calendar-outline', label: 'Events', color: colors.violet[500] },
  ];

  // Shimmer skeleton component
  const ShimmerCard = () => (
    <View style={styles.skeletonCard}>
      <LinearGradient
        colors={[colors.zinc[900], colors.zinc[800], colors.zinc[900]]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.skeletonImage}
      />
      <LinearGradient
        colors={[colors.zinc[900], colors.zinc[800], colors.zinc[900]]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.skeletonText}
      />
      <LinearGradient
        colors={[colors.zinc[900], colors.zinc[800], colors.zinc[900]]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={[styles.skeletonText, { width: '60%' }]}
      />
    </View>
  );

  if (loading) {
    return (
      <LinearGradient
        colors={[colors.gradientStart, colors.gradientEnd]}
        style={styles.container}
      >
        <View style={styles.header}>
          <View>
            <LinearGradient
              colors={[colors.zinc[900], colors.zinc[800], colors.zinc[900]]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.skeletonText, { width: 200, height: 32, marginBottom: 8 }]}
            />
            <LinearGradient
              colors={[colors.zinc[900], colors.zinc[800], colors.zinc[900]]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.skeletonText, { width: 100, height: 16 }]}
            />
          </View>
        </View>
        
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.quickActionsContainer}>
            <ScrollView horizontal contentContainerStyle={styles.quickActions}>
              {[1, 2, 3, 4].map((i) => (
                <View key={i} style={styles.actionCard}>
                  <LinearGradient
                    colors={[colors.zinc[900], colors.zinc[800], colors.zinc[900]]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={[styles.skeletonImage, { width: 56, height: 56, borderRadius: 16 }]}
                  />
                  <LinearGradient
                    colors={[colors.zinc[900], colors.zinc[800], colors.zinc[900]]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={[styles.skeletonText, { width: 60 }]}
                  />
                </View>
              ))}
            </ScrollView>
          </View>
          
          <View style={styles.section}>
            <LinearGradient
              colors={[colors.zinc[900], colors.zinc[800], colors.zinc[900]]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.skeletonText, { width: 150, marginHorizontal: spacing.lg, marginBottom: spacing.md }]}
            />
            <ScrollView horizontal contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md }}>
              {[1, 2, 3].map((i) => <ShimmerCard key={i} />)}
            </ScrollView>
          </View>
        </ScrollView>
      </LinearGradient>
    );
  }

  if (error) {
    return (
      <LinearGradient
        colors={[colors.gradientStart, colors.gradientEnd]}
        style={styles.container}
      >
        <View style={styles.errorContainer}>
          <Ionicons name="cloud-offline-outline" size={64} color={colors.zinc[600]} />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={loadHomeData}>
            <Ionicons name="refresh" size={20} color={colors.white} />
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientEnd]}
      style={styles.container}
    >
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={styles.greeting}>
              {getGreeting()}{userName ? `, ${userName}` : ''}! ✨
            </Text>
            {/* FIX #4: Tappable city selector */}
            <TouchableOpacity 
              style={styles.locationRow}
              onPress={() => router.push('/city-select-modal')}
            >
              <Ionicons name="location-outline" size={16} color={colors.zinc[500]} />
              <Text style={styles.location}>{city}</Text>
              <Ionicons name="chevron-down" size={14} color={colors.zinc[500]} />
              {weather && (
                <>
                  <Text style={styles.weatherDot}>•</Text>
                  <Text style={styles.weather}>
                    {getWeatherIcon(weather?.weather_code)} {Math.round(weather?.temperature_2m ?? 0)}°F
                  </Text>
                </>
              )}
            </TouchableOpacity>
            <Text style={styles.contextSubtitle}>{getContextualSubtitle()}</Text>
          </View>
          <TouchableOpacity style={styles.notificationButton}>
            <Ionicons name="notifications-outline" size={24} color={colors.white} />
            <View style={styles.notificationDot} />
          </TouchableOpacity>
        </View>

        {/* Hero CTA: Let Lumina Plan My Night */}
        <TouchableOpacity 
          style={styles.heroCta}
          onPress={() => router.push('/(tabs)/chat')}
        >
          <LinearGradient
            colors={[colors.violet[600], colors.violet[500]]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.heroGradient}
          >
            <Ionicons name="sparkles" size={24} color={colors.white} />
            <Text style={styles.heroText}>Let Lumina Plan My Night</Text>
            <Ionicons name="arrow-forward" size={20} color={colors.white} />
          </LinearGradient>
        </TouchableOpacity>

        {/* Quick Actions - Mini pill scroll */}
        <View style={styles.quickActionsContainer}>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickActions}
          >
            {quickActions.map((action, index) => (
              <TouchableOpacity 
                key={index} 
                style={styles.actionPill}
                onPress={() => handleQuickAction(action.label)}
              >
                <Ionicons name={action.icon as any} size={18} color={action.color} />
                <Text style={styles.actionPillLabel}>{action.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Tonight's Picks */}
        {tonightsPicks.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>✨ Tonight's Picks</Text>
              <TouchableOpacity onPress={() => router.push('/(tabs)/explore')}>
                <Text style={styles.seeAll}>See All</Text>
              </TouchableOpacity>
            </View>
            <VenueCarousel title="" venues={tonightsPicks} />
          </View>
        )}

        {/* Trending This Week */}
        {trendingVenues.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>🔥 Trending This Week</Text>
              <TouchableOpacity onPress={() => router.push('/(tabs)/explore')}>
                <Text style={styles.seeAll}>See All</Text>
              </TouchableOpacity>
            </View>
            <VenueCarousel title="" venues={trendingVenues} />
          </View>
        )}

        {/* Upcoming Events */}
        {upcomingEvents.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>🎉 Upcoming Events</Text>
              <TouchableOpacity onPress={() => router.push('/(tabs)/explore')}>
                <Text style={styles.seeAll}>See All</Text>
              </TouchableOpacity>
            </View>
            <EventCarousel title="" events={upcomingEvents} />
          </View>
        )}

        {/* FIX #6: Personalized Recommendations - respects profile completion */}
        {!profileCompleted && (
          <View style={styles.section}>
            <View style={styles.promoCard}>
              <LinearGradient
                colors={[colors.violet[600], colors.violet[500]]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.promoGradient}
              >
                <Ionicons name="sparkles" size={32} color={colors.white} />
                <Text style={styles.promoTitle}>Get Personalized Picks</Text>
                <Text style={styles.promoDescription}>
                  Complete your profile for AI-powered recommendations
                </Text>
                <TouchableOpacity 
                  style={styles.promoButton}
                  onPress={() => router.push('/onboarding')}
                >
                  <Text style={styles.promoButtonText}>Complete Profile</Text>
                  <Ionicons name="arrow-forward" size={16} color={colors.violet[600]} />
                </TouchableOpacity>
              </LinearGradient>
            </View>
          </View>
        )}

        {/* Popular Categories - FIX #7: Responsive grid */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { paddingHorizontal: spacing.lg, marginBottom: spacing.md }]}>
            Popular Right Now
          </Text>
          <View style={styles.categoryGrid}>
            {[
              { emoji: '🍝', name: 'Italian', filter: 'italian' },
              { emoji: '🎵', name: 'Afrobeats', filter: 'afrobeats' },
              { emoji: '🌃', name: 'Rooftop', filter: 'rooftop' },
              { emoji: '☕', name: 'Brunch', filter: 'brunch' },
            ].map((cat, idx) => (
              <TouchableOpacity 
                key={idx}
                style={styles.categoryCard}
                onPress={() => router.push(`/(tabs)/explore?filter=${cat.filter}`)}
              >
                <Text style={styles.categoryEmoji}>{cat.emoji}</Text>
                <Text style={styles.categoryName}>{cat.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingTop: 60,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
  },
  greeting: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.semibold,
    color: colors.white,
    marginBottom: spacing.xs,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginBottom: spacing.xs,
  },
  location: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
    fontWeight: '500',
  },
  weatherDot: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[600],
    marginLeft: spacing.xs,
  },
  weather: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
  },
  contextSubtitle: {
    fontSize: typography.sizes.sm,
    color: colors.violet[400],
    fontStyle: 'italic',
  },
  notificationButton: {
    position: 'relative',
    padding: spacing.sm,
    backgroundColor: colors.glass.medium,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.glass.border,
  },
  notificationDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.violet[500],
  },
  heroCta: {
    marginHorizontal: spacing.lg,
    marginBottom: spacing.lg,
    borderRadius: 16,
    overflow: 'hidden',
  },
  heroGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  heroText: {
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
  },
  quickActionsContainer: {
    marginBottom: spacing.lg,
  },
  quickActions: {
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  actionPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.glass.medium,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.glass.border,
  },
  actionPillLabel: {
    fontSize: typography.sizes.sm,
    fontWeight: '500',
    color: colors.white,
  },
  actionCard: {
    alignItems: 'center',
    gap: spacing.sm,
    minWidth: 80,
  },
  actionIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.glass.border,
  },
  actionLabel: {
    fontSize: typography.sizes.xs,
    fontWeight: '500',
    color: colors.white,
    textAlign: 'center',
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: '600',
    color: colors.white,
  },
  seeAll: {
    fontSize: typography.sizes.sm,
    fontWeight: '500',
    color: colors.violet[400],
  },
  promoCard: {
    marginHorizontal: spacing.lg,
    borderRadius: 20,
    overflow: 'hidden',
  },
  promoGradient: {
    padding: spacing.xl,
    alignItems: 'center',
    gap: spacing.sm,
  },
  promoTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: '600',
    color: colors.white,
    textAlign: 'center',
  },
  promoDescription: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    opacity: 0.9,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  promoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    backgroundColor: colors.white,
    borderRadius: 20,
  },
  promoButtonText: {
    fontSize: typography.sizes.sm,
    fontWeight: '600',
    color: colors.violet[600],
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: spacing.lg,
    gap: spacing.md,
  },
  categoryCard: {
    width: (SCREEN_WIDTH - spacing.lg * 2 - spacing.md) / 2,
    backgroundColor: colors.glass.medium,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.glass.border,
    padding: spacing.lg,
    alignItems: 'center',
    gap: spacing.sm,
  },
  categoryEmoji: {
    fontSize: 32,
  },
  categoryName: {
    fontSize: typography.sizes.sm,
    fontWeight: '500',
    color: colors.white,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
  },
  errorText: {
    fontSize: typography.sizes.md,
    color: colors.zinc[400],
    textAlign: 'center',
    marginTop: spacing.md,
    marginBottom: spacing.lg,
  },
  retryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    backgroundColor: colors.violet[600],
    borderRadius: 12,
  },
  retryButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
  },
  skeletonCard: {
    width: 280,
    backgroundColor: colors.glass.medium,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.glass.border,
    padding: spacing.md,
  },
  skeletonImage: {
    width: '100%',
    height: 160,
    backgroundColor: colors.zinc[800],
    borderRadius: 12,
    marginBottom: spacing.sm,
  },
  skeletonText: {
    height: 16,
    backgroundColor: colors.zinc[800],
    borderRadius: 8,
    marginBottom: spacing.xs,
  },
});
