import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Linking,
  StyleSheet,
  Dimensions,
  Share,
  Image,
  Animated,
  Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import luminaApi from '../../services/lumina';
import { colors, typography, spacing } from '../../theme';
import { getVibeGradient, glassStyles } from '../../theme/vibeGradients';
import EventCarousel from '../../components/EventCarousel';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const HEADER_HEIGHT = 400;

export default function EventDetailScreen() {
  const params = useLocalSearchParams();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  
  const [event, setEvent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [relatedEvents, setRelatedEvents] = useState<any[]>([]);
  const [vibeGradient, setVibeGradient] = useState<any>(null);
  const [contextMessage, setContextMessage] = useState<string>('');
  const [geoMessage, setGeoMessage] = useState<string>('');
  const [userLocation, setUserLocation] = useState<any>(null);

  useEffect(() => {
    if (id) {
      fetchEvent();
      loadUserLocation();
    }
  }, [id]);

  const loadUserLocation = async () => {
    try {
      const profile = await AsyncStorage.getItem('@lumina_profile');
      if (profile) {
        const data = JSON.parse(profile);
        setUserLocation({ city: data.city });
      }
    } catch (error) {
      console.log('Could not load user location');
    }
  };

  const fetchEvent = async () => {
    try {
      setLoading(true);
      const data = await luminaApi.getEventById(Number(id));
      setEvent(data);
      
      // Calculate dynamic gradient based on genre
      const genre = data.genre?.toLowerCase() || '';
      let gradientKey = 'high-energy';
      
      if (genre.includes('afrobeat')) gradientKey = 'afrobeats';
      else if (genre.includes('hip-hop') || genre.includes('rap')) gradientKey = 'hip-hop';
      else if (genre.includes('edm') || genre.includes('house')) gradientKey = 'edm';
      else if (genre.includes('latin')) gradientKey = 'afrobeats';
      else if (genre.includes('r&b') || genre.includes('rnb')) gradientKey = 'chill';
      
      const gradient = getVibeGradient([], [gradientKey], 'nightlife');
      setVibeGradient(gradient);
      
      // Set context message
      const eventDate = new Date(data.date);
      const today = new Date();
      const isTonight = eventDate.toDateString() === today.toDateString();
      const isTomorrow = eventDate.toDateString() === new Date(today.getTime() + 86400000).toDateString();
      
      if (isTonight) {
        setContextMessage("🔥 Tonight's event — get ready!");
      } else if (isTomorrow) {
        setContextMessage("⭐ Tomorrow night — plan ahead!");
      }
      
      // Set geo-aware message
      if (data.venue_name) {
        const neighborhood = data.venue_name.toLowerCase();
        if (neighborhood.includes('meatpacking')) {
          setGeoMessage("📍 Meatpacking District — expect upscale crowd and lines");
        } else if (neighborhood.includes('williamsburg')) {
          setGeoMessage("📍 Williamsburg — trendy Brooklyn vibes");
        } else if (neighborhood.includes('soho')) {
          setGeoMessage("📍 SoHo — sophisticated downtown scene");
        } else if (neighborhood.includes('midtown')) {
          setGeoMessage("📍 Midtown — central location, easy access");
        }
      }
      
      // Fetch related events
      if (data.genre) {
        try {
          const related = await luminaApi.getEventsByGenre(data.city, data.genre);
          setRelatedEvents(related.filter((e: any) => e.id !== Number(id)).slice(0, 6));
        } catch (e) {
          console.log('Could not fetch related events');
        }
      }
    } catch (error) {
      console.error('Error fetching event:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Check out ${event.title} with Lumina — your AI nightlife assistant. ${event.ticket_url || ''}`,
      });
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  const handleGetTickets = () => {
    if (event.ticket_url) {
      Linking.openURL(event.ticket_url);
    }
  };

  const handleVenuePress = () => {
    if (event.venue_id) {
      router.push(`/venue/${event.venue_id}`);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const formatTime = (timeString: string) => {
    if (!timeString) return '';
    if (timeString.includes(':')) {
      const [hours, minutes] = timeString.split(':');
      const hour = parseInt(hours);
      const ampm = hour >= 12 ? 'PM' : 'AM';
      const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
      return `${displayHour}:${minutes} ${ampm}`;
    }
    return timeString;
  };

  const parseLineup = (lineup: any) => {
    if (!lineup) return [];
    if (typeof lineup === 'string') {
      try {
        return JSON.parse(lineup);
      } catch {
        return lineup.split(',').map((s: string) => s.trim());
      }
    }
    return Array.isArray(lineup) ? lineup : [];
  };

  const getEventTimeline = (genre: string, time: string) => {
    const g = genre?.toLowerCase() || '';
    const baseTime = time || '10:00 PM';
    
    if (g.includes('brunch')) {
      return [
        { time: '11:00 AM', label: 'Doors Open', icon: 'time-outline', color: colors.orange[500] },
        { time: '12:30 PM', label: 'Peak Brunch', icon: 'flame', color: colors.orange[600] },
        { time: '4:00 PM', label: 'Closing', icon: 'moon-outline', color: colors.zinc[500] },
      ];
    }
    
    return [
      { time: baseTime, label: 'Doors Open', icon: 'time-outline', color: colors.violet[500] },
      { time: '12:00 AM', label: 'Headliner On', icon: 'musical-notes', color: colors.pink[500] },
      { time: '4:00 AM', label: 'Closing', icon: 'moon-outline', color: colors.zinc[500] },
    ];
  };

  // Parallax animations
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, HEADER_HEIGHT - 100],
    outputRange: [0, 1],
    extrapolate: 'clamp',
  });

  const imageScale = scrollY.interpolate({
    inputRange: [-100, 0],
    outputRange: [1.2, 1],
    extrapolate: 'clamp',
  });

  const imageTranslateY = scrollY.interpolate({
    inputRange: [0, HEADER_HEIGHT],
    outputRange: [0, -HEADER_HEIGHT / 2],
    extrapolate: 'clamp',
  });

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.violet[500]} />
        <Text style={styles.loadingText}>Loading event...</Text>
      </View>
    );
  }

  if (!event) {
    return (
      <View style={styles.loadingContainer}>
        <Ionicons name="alert-circle-outline" size={64} color={colors.zinc[600]} />
        <Text style={styles.errorText}>Event not found</Text>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const eventImage = event.image_url || 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819';
  const lineupArray = parseLineup(event.lineup);
  const timeline = getEventTimeline(event.genre, event.time);

  return (
    <View style={styles.container}>
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: true }
        )}
        scrollEventThrottle={16}
      >
        {/* Parallax Header */}
        <Animated.View
          style={[
            styles.header,
            {
              transform: [
                { translateY: imageTranslateY },
                { scale: imageScale },
              ],
            },
          ]}
        >
          <Image source={{ uri: eventImage }} style={styles.headerImage} />
          <LinearGradient
            colors={
              vibeGradient
                ? [...vibeGradient.colors.map((c: string) => c + '80'), 'rgba(0,0,0,0.95)']
                : ['transparent', 'rgba(0,0,0,0.8)']
            }
            style={styles.gradient}
          />
        </Animated.View>

        {/* Floating Header Bar */}
        <Animated.View
          style={[
            styles.floatingHeader,
            { top: insets.top, opacity: headerOpacity },
          ]}
        >
          <LinearGradient
            colors={['rgba(24, 24, 27, 0.95)', 'rgba(24, 24, 27, 0.8)']}
            style={[styles.floatingHeaderGradient, glassStyles.matte]}
          >
            <TouchableOpacity onPress={() => router.back()}>
              <Ionicons name="arrow-back" size={24} color={colors.white} />
            </TouchableOpacity>
            <Text style={styles.floatingHeaderTitle} numberOfLines={1}>
              {event.title}
            </Text>
            <View style={{ width: 24 }} />
          </LinearGradient>
        </Animated.View>

        {/* Back/Share Buttons */}
        <TouchableOpacity
          style={[styles.backButtonOverlay, { top: insets.top + 8 }]}
          onPress={() => router.back()}
        >
          <View style={[styles.iconButton, glassStyles.liquid]}>
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.shareButton, { top: insets.top + 8 }]}
          onPress={handleShare}
        >
          <View style={[styles.iconButton, glassStyles.liquid]}>
            <Ionicons name="share-outline" size={22} color="#fff" />
          </View>
        </TouchableOpacity>

        {/* Content */}
        <View style={styles.content}>
          <Text style={styles.eventTitle}>{event.title}</Text>

          {/* Context Messages */}
          <View style={styles.badgeRow}>
            {contextMessage && (
              <View style={[styles.contextBadge, glassStyles.liquid]}>
                <Text style={styles.contextText}>{contextMessage}</Text>
              </View>
            )}
            {geoMessage && (
              <View style={[styles.geoBadge, glassStyles.liquid]}>
                <Text style={styles.geoText}>{geoMessage}</Text>
              </View>
            )}
          </View>

          {/* AI-Generated Bio - WHY THIS EVENT IS WORTH GOING */}
          {event.why_recommended && (
            <View style={styles.whyRecommendedCard}>
              <LinearGradient
                colors={
                  vibeGradient
                    ? vibeGradient.colors.map((c: string) => c + '30')
                    : [colors.violet[500] + '20', colors.violet[600] + '10']
                }
                style={[styles.whyRecommendedGradient, glassStyles.liquid]}
              >
                <Ionicons name="sparkles" size={20} color={colors.violet[400]} />
                <View style={styles.whyRecommendedContent}>
                  <Text style={styles.whyRecommendedTitle}>✨ Why this event is worth going</Text>
                  <Text style={styles.whyRecommendedText}>{event.why_recommended}</Text>
                </View>
              </LinearGradient>
            </View>
          )}

          {/* Crowd Type */}
          {event.crowd_type && (
            <View style={[styles.crowdCard, glassStyles.matte]}>
              <Ionicons name="people" size={20} color={colors.pink[400]} />
              <Text style={styles.crowdTitle}>Expected Crowd:</Text>
              <Text style={styles.crowdText}>{event.crowd_type}</Text>
            </View>
          )}

          {/* Peak Hours Analysis */}
          {event.peak_hours && (
            <View style={styles.peakHoursCard}>
              <LinearGradient
                colors={[colors.orange[500] + '30', colors.red[500] + '20']}
                style={[styles.peakHoursGradient, glassStyles.liquid]}
              >
                <View style={styles.peakHoursHeader}>
                  <Ionicons name="flame" size={24} color={colors.orange[400]} />
                  <Text style={styles.peakHoursTitle}>Peak Hours</Text>
                </View>
                <Text style={styles.peakHoursText}>{event.peak_hours}</Text>
              </LinearGradient>
            </View>
          )}

          {/* Event Timeline */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>📅 Event Timeline</Text>
            <View style={styles.timelineContainer}>
              {timeline.map((item, index) => (
                <View key={index} style={[styles.timelineItem, glassStyles.matte]}>
                  <View style={[styles.timelineIcon, { backgroundColor: item.color + '30' }]}>
                    <Ionicons name={item.icon as any} size={20} color={item.color} />
                  </View>
                  <View style={styles.timelineContent}>
                    <Text style={styles.timelineLabel}>{item.label}</Text>
                    <Text style={styles.timelineTime}>{item.time}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Event Info Cards */}
          <View style={styles.infoCards}>
            <View style={[styles.infoCard, glassStyles.matte]}>
              <Ionicons name="calendar" size={24} color={colors.violet[500]} />
              <View style={styles.infoCardText}>
                <Text style={styles.infoCardLabel}>Date</Text>
                <Text style={styles.infoCardValue}>{formatDate(event.date)}</Text>
              </View>
            </View>

            {event.time && (
              <View style={[styles.infoCard, glassStyles.matte]}>
                <Ionicons name="time" size={24} color={colors.violet[500]} />
                <View style={styles.infoCardText}>
                  <Text style={styles.infoCardLabel}>Time</Text>
                  <Text style={styles.infoCardValue}>{formatTime(event.time)}</Text>
                </View>
              </View>
            )}

            {event.genre && (
              <View style={[styles.infoCard, glassStyles.matte]}>
                <Ionicons name="musical-notes" size={24} color={colors.violet[500]} />
                <View style={styles.infoCardText}>
                  <Text style={styles.infoCardLabel}>Genre</Text>
                  <Text style={styles.infoCardValue}>{event.genre}</Text>
                </View>
              </View>
            )}
          </View>

          {/* Description */}
          {event.description && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>About This Event</Text>
              <View style={[styles.descriptionCard, glassStyles.matte]}>
                <Text style={styles.descriptionText}>{event.description}</Text>
              </View>
            </View>
          )}

          {/* Lineup */}
          {lineupArray.length > 0 && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>🎤 Lineup</Text>
              <View style={styles.lineupContainer}>
                {lineupArray.map((artist: string, index: number) => (
                  <View key={index} style={[styles.lineupItem, glassStyles.liquid]}>
                    <View style={styles.lineupAvatar}>
                      <Ionicons name="person" size={20} color={colors.violet[400]} />
                    </View>
                    <Text style={styles.lineupText}>{artist}</Text>
                    {index === 0 && (
                      <View style={styles.headlinerBadge}>
                        <Text style={styles.headlinerText}>HEADLINER</Text>
                      </View>
                    )}
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Venue Card */}
          {event.venue_name && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>📍 Location</Text>
              <TouchableOpacity
                style={[styles.venueCard, glassStyles.liquid]}
                onPress={handleVenuePress}
                activeOpacity={0.8}
              >
                <View style={styles.venueIcon}>
                  <Ionicons name="location" size={28} color={colors.violet[500]} />
                </View>
                <View style={styles.venueInfo}>
                  <Text style={styles.venueName}>{event.venue_name}</Text>
                  {event.venue_address && (
                    <Text style={styles.venueAddress}>{event.venue_address}</Text>
                  )}
                </View>
                <Ionicons name="chevron-forward" size={24} color={colors.zinc[600]} />
              </TouchableOpacity>
            </View>
          )}

          {/* Related Events */}
          {relatedEvents.length > 0 && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>More {event.genre} Events</Text>
              <EventCarousel title="" events={relatedEvents} />
            </View>
          )}
        </View>

        <View style={{ height: 140 }} />
      </Animated.ScrollView>

      {/* Floating Ticket CTA */}
      {event.ticket_url && (
        <View style={[styles.floatingTicketBar, { bottom: insets.bottom + 16 }]}>
          <LinearGradient
            colors={
              vibeGradient
                ? vibeGradient.colors
                : [colors.violet[600], colors.violet[700]]
            }
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={[styles.ticketBarGradient, glassStyles.liquid]}
          >
            <View style={styles.ticketBarLeft}>
              <Text style={styles.ticketBarTitle}>Ready to go?</Text>
              <Text style={styles.ticketBarSubtitle}>Secure your spot now</Text>
            </View>
            <TouchableOpacity
              style={styles.ticketButton}
              onPress={handleGetTickets}
              activeOpacity={0.8}
            >
              <Ionicons name="ticket" size={20} color={colors.white} />
              <Text style={styles.ticketButtonText}>Get Tickets</Text>
            </TouchableOpacity>
          </LinearGradient>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.zinc[900] },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.zinc[900],
    gap: spacing.md,
  },
  loadingText: { fontSize: typography.sizes.md, color: colors.zinc[400] },
  errorText: { fontSize: typography.sizes.lg, color: colors.zinc[400], marginTop: spacing.md },
  backBtn: {
    marginTop: spacing.lg,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    backgroundColor: colors.violet[600],
    borderRadius: 12,
  },
  backBtnText: { fontSize: typography.sizes.md, fontWeight: '600', color: colors.white },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 160 },
  header: { height: HEADER_HEIGHT, position: 'relative' },
  headerImage: { width: '100%', height: '100%' },
  gradient: { position: 'absolute', bottom: 0, left: 0, right: 0, height: '70%' },
  floatingHeader: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 100,
  },
  floatingHeaderGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  floatingHeaderTitle: {
    flex: 1,
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
    marginHorizontal: spacing.md,
  },
  backButtonOverlay: {
    position: 'absolute',
    left: 16,
    zIndex: 10,
  },
  shareButton: {
    position: 'absolute',
    right: 16,
    zIndex: 10,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    backgroundColor: colors.zinc[900],
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    marginTop: -20,
    paddingTop: spacing.xl,
    paddingHorizontal: spacing.lg,
  },
  eventTitle: {
    fontSize: typography.sizes.xxl,
    fontWeight: '700',
    color: colors.white,
    marginBottom: spacing.md,
  },
  badgeRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.lg,
    flexWrap: 'wrap',
  },
  contextBadge: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
  },
  contextText: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    fontWeight: '600',
  },
  geoBadge: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
  },
  geoText: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    fontWeight: '600',
  },
  whyRecommendedCard: {
    marginBottom: spacing.lg,
    borderRadius: 16,
    overflow: 'hidden',
  },
  whyRecommendedGradient: {
    flexDirection: 'row',
    gap: spacing.md,
    padding: spacing.lg,
    alignItems: 'flex-start',
  },
  whyRecommendedContent: {
    flex: 1,
  },
  whyRecommendedTitle: {
    fontSize: typography.sizes.sm,
    color: colors.violet[300],
    fontWeight: '700',
    marginBottom: spacing.xs,
    textTransform: 'uppercase',
  },
  whyRecommendedText: {
    fontSize: typography.sizes.md,
    color: colors.white,
    lineHeight: 22,
    fontStyle: 'italic',
  },
  crowdCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: 16,
    marginBottom: spacing.md,
  },
  crowdTitle: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
    fontWeight: '600',
  },
  crowdText: {
    flex: 1,
    fontSize: typography.sizes.sm,
    color: colors.white,
    fontWeight: '600',
  },
  peakHoursCard: {
    marginBottom: spacing.lg,
    borderRadius: 16,
    overflow: 'hidden',
  },
  peakHoursGradient: {
    padding: spacing.lg,
  },
  peakHoursHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  peakHoursTitle: {
    fontSize: typography.sizes.md,
    fontWeight: '700',
    color: colors.white,
  },
  peakHoursText: {
    fontSize: typography.sizes.md,
    color: colors.white,
    lineHeight: 22,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: '700',
    color: colors.white,
    marginBottom: spacing.md,
  },
  timelineContainer: {
    gap: spacing.md,
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: 16,
  },
  timelineIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  timelineContent: {
    flex: 1,
  },
  timelineLabel: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
    marginBottom: spacing.xs,
  },
  timelineTime: {
    fontSize: typography.sizes.md,
    color: colors.white,
    fontWeight: '600',
  },
  infoCards: {
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: 16,
  },
  infoCardText: {
    flex: 1,
  },
  infoCardLabel: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[500],
    marginBottom: spacing.xs,
    textTransform: 'uppercase',
    fontWeight: '600',
  },
  infoCardValue: {
    fontSize: typography.sizes.md,
    color: colors.white,
    fontWeight: '600',
  },
  descriptionCard: {
    padding: spacing.lg,
    borderRadius: 16,
  },
  descriptionText: {
    fontSize: typography.sizes.md,
    color: colors.zinc[300],
    lineHeight: 24,
  },
  lineupContainer: {
    gap: spacing.sm,
  },
  lineupItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: 16,
  },
  lineupAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.violet[500] + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  lineupText: {
    flex: 1,
    fontSize: typography.sizes.md,
    color: colors.white,
    fontWeight: '600',
  },
  headlinerBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    backgroundColor: colors.pink[500],
    borderRadius: 8,
  },
  headlinerText: {
    fontSize: typography.sizes.xs,
    color: colors.white,
    fontWeight: '700',
  },
  venueCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.lg,
    borderRadius: 16,
    gap: spacing.md,
  },
  venueIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.violet[500] + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  venueInfo: {
    flex: 1,
  },
  venueName: {
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
    marginBottom: spacing.xs,
  },
  venueAddress: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
  },
  floatingTicketBar: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    borderRadius: 20,
    overflow: 'hidden',
  },
  ticketBarGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  ticketBarLeft: {
    flex: 1,
  },
  ticketBarTitle: {
    fontSize: typography.sizes.md,
    fontWeight: '700',
    color: colors.white,
    marginBottom: spacing.xs,
  },
  ticketBarSubtitle: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    opacity: 0.9,
  },
  ticketButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: 20,
  },
  ticketButtonText: {
    fontSize: typography.sizes.md,
    fontWeight: '700',
    color: colors.white,
  },
});
