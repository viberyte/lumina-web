import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Linking,
  StyleSheet,
  Dimensions,
  Share,
  Image,
  Animated,
  Modal,
  Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import luminaApi from '../../services/lumina';
import { colors, typography, spacing } from '../../theme';
import { getVibeGradient, glassStyles } from '../../theme/vibeGradients';
import VenueCarousel from '../../components/VenueCarousel';
import EventCarousel from '../../components/EventCarousel';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const HEADER_HEIGHT = 400;

export default function VenueDetailScreen() {
  const params = useLocalSearchParams();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  
  const [venue, setVenue] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isFavorited, setIsFavorited] = useState(false);
  const [activeTab, setActiveTab] = useState('Overview');
  const [fullscreenPhoto, setFullscreenPhoto] = useState<string | null>(null);
  const [relatedVenues, setRelatedVenues] = useState<any[]>([]);
  const [venueEvents, setVenueEvents] = useState<any[]>([]);
  const [vibeGradient, setVibeGradient] = useState<any>(null);
  const [contextMessage, setContextMessage] = useState<string>('');

  useEffect(() => {
    if (id) {
      fetchVenue();
      checkFavorite();
    }
  }, [id]);

  const fetchVenue = async () => {
    try {
      setLoading(true);
      const data = await luminaApi.getVenueById(Number(id));
      setVenue(data);
      
      // Calculate dynamic vibe gradient
      const vibeTags = parseArray(data.vibe_tags);
      const musicGenres = parseArray(data.music_genres);
      const hour = new Date().getHours();
      const day = new Date().getDay();
      
      const gradient = getVibeGradient(
        vibeTags,
        musicGenres,
        data.category,
        undefined,
        { hour, day }
      );
      
      setVibeGradient(gradient);
      setContextMessage(getContextMessage(data, hour, day, vibeTags));
      
      // Fetch related venues
      if (data.category) {
        const related = await luminaApi.getVenuesByCategory(data.city, data.category);
        setRelatedVenues(related.filter((v: any) => v.id !== Number(id)).slice(0, 6));
      }
      
      // Fetch events at this venue
      if (data.id) {
        try {
          const events = await luminaApi.getEventsByVenue(data.id);
          setVenueEvents(events);
        } catch (e) {
          console.log('No events endpoint available');
        }
      }
    } catch (error) {
      console.error('Error fetching venue:', error);
    } finally {
      setLoading(false);
    }
  };

  const getContextMessage = (venue: any, hour: number, day: number, vibeTags: string[]) => {
    // Saturday night high energy
    if (day === 6 && hour >= 20 && vibeTags.includes('high-energy')) {
      return "🔥 Saturday night energy at this spot!";
    }
    
    // Sunday brunch
    if (day === 0 && hour >= 10 && hour < 15 && vibeTags.includes('brunch')) {
      return "🥂 Sunday Funday vibes";
    }
    
    // Late night
    if (hour >= 22 || hour < 4) {
      return "🌙 Late night magic happens here";
    }
    
    // Rooftop during day
    if (vibeTags.includes('rooftop') && hour >= 11 && hour < 20) {
      return "☀️ Perfect weather for rooftop vibes";
    }
    
    // Upscale evening
    if (vibeTags.includes('upscale') && hour >= 18) {
      return "✨ Sophisticated evening atmosphere";
    }
    
    return "";
  };

  const checkFavorite = async () => {
    try {
      const favorites = await AsyncStorage.getItem('@lumina_favorites');
      if (favorites) {
        const favArray = JSON.parse(favorites);
        setIsFavorited(favArray.includes(Number(id)));
      }
    } catch (error) {
      console.error('Error checking favorite:', error);
    }
  };

  const handleFavorite = async () => {
    try {
      const favorites = await AsyncStorage.getItem('@lumina_favorites');
      let favArray = favorites ? JSON.parse(favorites) : [];
      
      if (isFavorited) {
        favArray = favArray.filter((fav: number) => fav !== Number(id));
      } else {
        favArray.push(Number(id));
      }
      
      await AsyncStorage.setItem('@lumina_favorites', JSON.stringify(favArray));
      setIsFavorited(!isFavorited);
    } catch (error) {
      console.error('Error updating favorite:', error);
    }
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Discover ${venue.name} with Lumina — your AI nightlife assistant. ${venue.website || ''}`,
      });
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  const handleCall = () => {
    if (venue.phone) {
      Linking.openURL(`tel:${venue.phone}`);
    }
  };

  const handleDirections = () => {
    if (venue.latitude && venue.longitude) {
      const url = Platform.select({
        ios: `maps:0,0?q=${venue.name}@${venue.latitude},${venue.longitude}`,
        android: `geo:0,0?q=${venue.latitude},${venue.longitude}(${venue.name})`,
      });
      Linking.openURL(url!);
    }
  };

  const handleWebsite = () => {
    if (venue.website) {
      Linking.openURL(venue.website);
    }
  };

  const parsePhotos = (photos: any) => {
    if (!photos) return [];
    if (typeof photos === 'string') {
      try {
        return JSON.parse(photos);
      } catch {
        return [];
      }
    }
    return Array.isArray(photos) ? photos : [];
  };

  const parseArray = (data: any) => {
    if (!data) return [];
    if (typeof data === 'string') {
      try {
        return JSON.parse(data);
      } catch {
        return [];
      }
    }
    return Array.isArray(data) ? data : [];
  };

  // Parallax animations
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, HEADER_HEIGHT - 100],
    outputRange: [0, 1],
    extrapolate: 'clamp',
  });

  const imageScale = scrollY.interpolate({
    inputRange: [-100, 0],
    outputRange: [1.2, 1],
    extrapolate: 'clamp',
  });

  const imageTranslateY = scrollY.interpolate({
    inputRange: [0, HEADER_HEIGHT],
    outputRange: [0, -HEADER_HEIGHT / 2],
    extrapolate: 'clamp',
  });

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.violet[500]} />
        <Text style={styles.loadingText}>Loading venue...</Text>
      </View>
    );
  }

  if (!venue) {
    return (
      <View style={styles.loadingContainer}>
        <Ionicons name="alert-circle-outline" size={64} color={colors.zinc[600]} />
        <Text style={styles.errorText}>Venue not found</Text>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const googlePhotos = parsePhotos(venue.google_photos);
  const allPhotos = googlePhotos.length > 0 ? googlePhotos : [venue.image_url].filter(Boolean);
  const venueImage = allPhotos[0] || 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4';
  const vibeTags = parseArray(venue.vibe_tags);
  const musicGenres = parseArray(venue.music_genres);
  const cuisineTypes = parseArray(venue.cuisine_types);

  return (
    <View style={styles.container}>
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: true }
        )}
        scrollEventThrottle={16}
      >
        {/* Parallax Header with Dynamic Gradient Overlay */}
        <Animated.View
          style={[
            styles.header,
            {
              transform: [
                { translateY: imageTranslateY },
                { scale: imageScale },
              ],
            },
          ]}
        >
          <Image source={{ uri: venueImage }} style={styles.headerImage} />
          <LinearGradient
            colors={
              vibeGradient
                ? [...vibeGradient.colors.map((c: string) => c + '80'), 'rgba(0,0,0,0.95)']
                : ['transparent', 'rgba(0,0,0,0.8)']
            }
            style={styles.gradient}
          />
        </Animated.View>

        {/* Floating Header Bar */}
        <Animated.View
          style={[
            styles.floatingHeader,
            { top: insets.top, opacity: headerOpacity },
          ]}
        >
          <LinearGradient
            colors={['rgba(24, 24, 27, 0.95)', 'rgba(24, 24, 27, 0.8)']}
            style={[styles.floatingHeaderGradient, glassStyles.matte]}
          >
            <TouchableOpacity onPress={() => router.back()}>
              <Ionicons name="arrow-back" size={24} color={colors.white} />
            </TouchableOpacity>
            <Text style={styles.floatingHeaderTitle} numberOfLines={1}>
              {venue.name}
            </Text>
            <View style={{ width: 24 }} />
          </LinearGradient>
        </Animated.View>

        {/* Back/Share Buttons */}
        <TouchableOpacity
          style={[styles.backButtonOverlay, { top: insets.top + 8 }]}
          onPress={() => router.back()}
        >
          <View style={[styles.iconButton, glassStyles.liquid]}>
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </View>
        </TouchableOpacity>

        <View style={[styles.headerActions, { top: insets.top + 8 }]}>
          <TouchableOpacity onPress={handleShare}>
            <View style={[styles.iconButton, glassStyles.liquid]}>
              <Ionicons name="share-outline" size={22} color="#fff" />
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleFavorite}>
            <View style={[styles.iconButton, glassStyles.liquid]}>
              <Ionicons
                name={isFavorited ? 'heart' : 'heart-outline'}
                size={22}
                color={isFavorited ? '#ef4444' : '#fff'}
              />
            </View>
          </TouchableOpacity>
        </View>

        {/* Content */}
        <View style={styles.content}>
          <Text style={styles.venueName}>{venue.name}</Text>
          
          {/* Context Message - Dynamic based on time/vibe */}
          {contextMessage && (
            <View style={[styles.contextBadge, glassStyles.liquid]}>
              <Text style={styles.contextText}>{contextMessage}</Text>
            </View>
          )}
          
          <View style={styles.metaRow}>
            <View style={[styles.metaBadge, glassStyles.matte]}>
              <Ionicons name="location" size={14} color={colors.violet[400]} />
              <Text style={styles.neighborhood}>{venue.neighborhood || venue.city}</Text>
            </View>
            {venue.rating && (
              <View style={[styles.metaBadge, glassStyles.matte]}>
                <Text style={styles.rating}>⭐ {venue.rating.toFixed(1)}</Text>
              </View>
            )}
            {venue.price_tier && (
              <View style={[styles.metaBadge, glassStyles.matte]}>
                <Text style={styles.priceTier}>{venue.price_tier}</Text>
              </View>
            )}
          </View>

          {/* AI-Generated Bio with Liquid Glass */}
          {venue.why_recommended && (
            <View style={styles.whyRecommendedCard}>
              <LinearGradient
                colors={
                  vibeGradient
                    ? vibeGradient.colors.map((c: string) => c + '30')
                    : [colors.violet[500] + '20', colors.violet[600] + '10']
                }
                style={[styles.whyRecommendedGradient, glassStyles.liquid]}
              >
                <Ionicons name="sparkles" size={20} color={colors.violet[400]} />
                <Text style={styles.whyRecommendedText}>{venue.why_recommended}</Text>
              </LinearGradient>
            </View>
          )}

          {/* Tabs with Matte Glass */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.tabs}
            contentContainerStyle={styles.tabsContent}
          >
            {['Overview', 'Photos', 'Menu', 'Events'].map((tab) => (
              <TouchableOpacity
                key={tab}
                style={[
                  styles.tab,
                  activeTab === tab && styles.activeTab,
                  glassStyles.matte,
                ]}
                onPress={() => setActiveTab(tab)}
              >
                <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>
                  {tab}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Tab Content */}
          {activeTab === 'Overview' && (
            <View style={styles.tabContent}>
              {/* Vibe Tags with Dynamic Colors */}
              {vibeTags.length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>✨ Vibe</Text>
                  <View style={styles.chipContainer}>
                    {vibeTags.map((tag: string, index: number) => (
                      <View key={index} style={[styles.chip, glassStyles.liquid]}>
                        <Text style={styles.chipText}>{tag}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}

              {/* Music Genres */}
              {musicGenres.length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>🎵 Music</Text>
                  <View style={styles.chipContainer}>
                    {musicGenres.map((genre: string, index: number) => (
                      <View key={index} style={[styles.chip, styles.chipMusic, glassStyles.liquid]}>
                        <Text style={styles.chipText}>{genre}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}

              {/* Cuisine Types */}
              {cuisineTypes.length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>🍽️ Cuisine</Text>
                  <View style={styles.chipContainer}>
                    {cuisineTypes.map((cuisine: string, index: number) => (
                      <View key={index} style={[styles.chip, styles.chipCuisine, glassStyles.liquid]}>
                        <Text style={styles.chipText}>{cuisine}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}

              {/* Contact Info with Matte Glass */}
              <View style={styles.section}>
                {venue.address && (
                  <TouchableOpacity style={[styles.infoRow, glassStyles.matte]} onPress={handleDirections}>
                    <Ionicons name="location" size={20} color={colors.violet[500]} />
                    <Text style={styles.infoText}>{venue.address}</Text>
                    <Ionicons name="chevron-forward" size={20} color={colors.zinc[600]} />
                  </TouchableOpacity>
                )}
                {venue.phone && (
                  <TouchableOpacity style={[styles.infoRow, glassStyles.matte]} onPress={handleCall}>
                    <Ionicons name="call" size={20} color={colors.violet[500]} />
                    <Text style={styles.infoText}>{venue.phone}</Text>
                    <Ionicons name="chevron-forward" size={20} color={colors.zinc[600]} />
                  </TouchableOpacity>
                )}
                {venue.website && (
                  <TouchableOpacity style={[styles.infoRow, glassStyles.matte]} onPress={handleWebsite}>
                    <Ionicons name="globe" size={20} color={colors.violet[500]} />
                    <Text style={styles.infoText}>Visit Website</Text>
                    <Ionicons name="chevron-forward" size={20} color={colors.zinc[600]} />
                  </TouchableOpacity>
                )}
              </View>

              {/* Related Venues */}
              {relatedVenues.length > 0 && (
                <View style={styles.section}>
                  <Text style={styles.sectionTitle}>You might also like</Text>
                  <VenueCarousel title="" venues={relatedVenues} />
                </View>
              )}
            </View>
          )}

          {activeTab === 'Photos' && (
            <View style={styles.tabContent}>
              <View style={styles.photoGrid}>
                {allPhotos.slice(0, 12).map((photo: string, index: number) => (
                  <TouchableOpacity
                    key={index}
                    onPress={() => setFullscreenPhoto(photo)}
                  >
                    <Image source={{ uri: photo }} style={styles.gridPhoto} />
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {activeTab === 'Menu' && (
            <View style={styles.tabContent}>
              <Text style={styles.placeholderText}>Menu coming soon</Text>
            </View>
          )}

          {activeTab === 'Events' && (
            <View style={styles.tabContent}>
              {venueEvents.length > 0 ? (
                <EventCarousel title="" events={venueEvents} />
              ) : (
                <Text style={styles.placeholderText}>No upcoming events</Text>
              )}
            </View>
          )}
        </View>

        <View style={{ height: 100 }} />
      </Animated.ScrollView>

      {/* Floating Action Bar with Liquid Glass */}
      <View style={[styles.floatingActionBar, { bottom: insets.bottom + 16 }]}>
        <LinearGradient
          colors={
            vibeGradient
              ? vibeGradient.colors
              : [colors.violet[600], colors.violet[700]]
          }
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={[styles.actionBarGradient, glassStyles.liquid]}
        >
          {venue.phone && (
            <TouchableOpacity style={styles.actionBarButton} onPress={handleCall}>
              <Ionicons name="call-outline" size={20} color={colors.white} />
              <Text style={styles.actionBarButtonText}>Call</Text>
            </TouchableOpacity>
          )}
          
          <TouchableOpacity style={styles.actionBarButton} onPress={handleDirections}>
            <Ionicons name="navigate-outline" size={20} color={colors.white} />
            <Text style={styles.actionBarButtonText}>Directions</Text>
          </TouchableOpacity>

          {venue.website && (
            <TouchableOpacity style={styles.actionBarButton} onPress={handleWebsite}>
              <Ionicons name="globe-outline" size={20} color={colors.white} />
              <Text style={styles.actionBarButtonText}>Website</Text>
            </TouchableOpacity>
          )}
        </LinearGradient>
      </View>

      {/* Fullscreen Photo Modal */}
      <Modal visible={!!fullscreenPhoto} transparent animationType="fade">
        <View style={styles.fullscreenModal}>
          <TouchableOpacity
            style={styles.closeFullscreen}
            onPress={() => setFullscreenPhoto(null)}
          >
            <View style={[styles.iconButton, glassStyles.liquid]}>
              <Ionicons name="close" size={32} color={colors.white} />
            </View>
          </TouchableOpacity>
          {fullscreenPhoto && (
            <Image
              source={{ uri: fullscreenPhoto }}
              style={styles.fullscreenImage}
              resizeMode="contain"
            />
          )}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.zinc[900] },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.zinc[900],
    gap: spacing.md,
  },
  loadingText: { fontSize: typography.sizes.md, color: colors.zinc[400] },
  errorText: { fontSize: typography.sizes.lg, color: colors.zinc[400], marginTop: spacing.md },
  backBtn: {
    marginTop: spacing.lg,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    backgroundColor: colors.violet[600],
    borderRadius: 12,
  },
  backBtnText: { fontSize: typography.sizes.md, fontWeight: '600', color: colors.white },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120 },
  header: { height: HEADER_HEIGHT, position: 'relative' },
  headerImage: { width: '100%', height: '100%' },
  gradient: { position: 'absolute', bottom: 0, left: 0, right: 0, height: '70%' },
  floatingHeader: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 100,
  },
  floatingHeaderGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  floatingHeaderTitle: {
    flex: 1,
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
    marginHorizontal: spacing.md,
  },
  backButtonOverlay: {
    position: 'absolute',
    left: 16,
    zIndex: 10,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerActions: {
    position: 'absolute',
    right: 16,
    flexDirection: 'row',
    gap: 12,
    zIndex: 10,
  },
  content: {
    backgroundColor: colors.zinc[900],
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    marginTop: -20,
    paddingTop: spacing.xl,
  },
  venueName: {
    fontSize: typography.sizes.xxl,
    fontWeight: '700',
    color: colors.white,
    marginBottom: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  contextBadge: {
    alignSelf: 'flex-start',
    marginLeft: spacing.lg,
    marginBottom: spacing.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
  },
  contextText: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    fontWeight: '600',
  },
  metaRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.lg,
    flexWrap: 'wrap',
  },
  metaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: 16,
  },
  neighborhood: {
    fontSize: typography.sizes.sm,
    color: colors.violet[400],
    fontWeight: '600',
  },
  rating: { fontSize: typography.sizes.sm, color: colors.white, fontWeight: '600' },
  priceTier: { fontSize: typography.sizes.sm, color: colors.zinc[400], fontWeight: '600' },
  whyRecommendedCard: {
    marginHorizontal: spacing.lg,
    marginBottom: spacing.lg,
    borderRadius: 16,
    overflow: 'hidden',
  },
  whyRecommendedGradient: {
    flexDirection: 'row',
    gap: spacing.md,
    padding: spacing.lg,
    alignItems: 'flex-start',
  },
  whyRecommendedText: {
    flex: 1,
    fontSize: typography.sizes.md,
    color: colors.white,
    lineHeight: 22,
    fontStyle: 'italic',
  },
  tabs: {
    marginBottom: spacing.lg,
  },
  tabsContent: {
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  tab: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: 20,
  },
  activeTab: {
    backgroundColor: colors.violet[600] + '40',
  },
  tabText: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
    fontWeight: '600',
  },
  activeTabText: { color: colors.white },
  tabContent: { paddingHorizontal: spacing.lg },
  section: { marginBottom: spacing.xl },
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: '700',
    color: colors.white,
    marginBottom: spacing.md,
  },
  chipContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 16,
  },
  chipMusic: {
    backgroundColor: colors.blue[500] + '30',
  },
  chipCuisine: {
    backgroundColor: colors.orange[500] + '30',
  },
  chipText: {
    fontSize: typography.sizes.sm,
    color: colors.white,
    fontWeight: '600',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderRadius: 12,
    marginBottom: spacing.sm,
  },
  infoText: {
    flex: 1,
    fontSize: typography.sizes.md,
    color: colors.zinc[300],
  },
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  gridPhoto: {
    width: (SCREEN_WIDTH - spacing.lg * 2 - spacing.sm * 2) / 3,
    height: (SCREEN_WIDTH - spacing.lg * 2 - spacing.sm * 2) / 3,
    borderRadius: 12,
  },
  placeholderText: {
    fontSize: typography.sizes.md,
    color: colors.zinc[400],
    textAlign: 'center',
    paddingVertical: spacing.xxl,
  },
  floatingActionBar: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    borderRadius: 20,
    overflow: 'hidden',
  },
  actionBarGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  actionBarButton: {
    alignItems: 'center',
    gap: spacing.xs,
  },
  actionBarButtonText: {
    fontSize: typography.sizes.xs,
    color: colors.white,
    fontWeight: '600',
  },
  fullscreenModal: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.95)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeFullscreen: {
    position: 'absolute',
    top: 60,
    right: 20,
    zIndex: 10,
  },
  fullscreenImage: {
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT,
  },
});
