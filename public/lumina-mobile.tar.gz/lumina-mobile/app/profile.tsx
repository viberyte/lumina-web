import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing } from '../theme';
import favoritesService, { FavoriteVenue } from '../services/favorites';

const { width } = Dimensions.get('window');

export default function ProfileScreen() {
  const router = useRouter();
  const [favorites, setFavorites] = useState<FavoriteVenue[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    const favs = await favoritesService.getFavorites();
    setFavorites(favs);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadFavorites();
    setRefreshing(false);
  };

  const removeFavorite = async (venueId: string) => {
    await favoritesService.removeFavorite(venueId);
    loadFavorites();
  };

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientEnd]}
      style={styles.container}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={24} color={colors.white} />
          </TouchableOpacity>
          <TouchableOpacity>
            <Ionicons name="settings-outline" size={24} color={colors.white} />
          </TouchableOpacity>
        </View>

        <View style={styles.profileInfo}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>✨</Text>
          </View>
          <Text style={styles.name}>Lumina Member</Text>
          <Text style={styles.subtitle}>Manhattan</Text>
        </View>

        <View style={styles.stats}>
          <View style={styles.stat}>
            <Text style={styles.statNumber}>{favorites.length}</Text>
            <Text style={styles.statLabel}>Saved</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.stat}>
            <Text style={styles.statNumber}>0</Text>
            <Text style={styles.statLabel}>Visited</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.stat}>
            <Text style={styles.statNumber}>0</Text>
            <Text style={styles.statLabel}>Reviews</Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Saved Venues Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>❤️ Saved Venues</Text>
            <TouchableOpacity onPress={handleRefresh}>
              <Ionicons name="refresh" size={20} color={colors.zinc[500]} />
            </TouchableOpacity>
          </View>

          {favorites.length === 0 ? (
            <View style={styles.emptyState}>
              <Ionicons name="heart-outline" size={60} color={colors.zinc[700]} />
              <Text style={styles.emptyTitle}>No saved venues yet</Text>
              <Text style={styles.emptyText}>
                Start exploring and save your favorite spots
              </Text>
              <TouchableOpacity style={styles.exploreButton} onPress={() => router.push('/home')}>
                <Text style={styles.exploreButtonText}>Explore Venues</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.favoritesList}>
              {favorites.map((venue) => (
                <TouchableOpacity
                  key={venue.id}
                  style={styles.favoriteCard}
                  onPress={() => router.push({
                    pathname: '/venue/[id]',
                    params: { id: venue.id, venue: JSON.stringify(venue) },
                  })}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={['#FFFFFF', '#F4F4F4']}
                    style={styles.favoriteGradient}
                  >
                    {venue.professional_photo_url && (
                      <Image
                        source={{ uri: venue.professional_photo_url }}
                        style={styles.favoriteImage}
                        resizeMode="cover"
                      />
                    )}

                    <View style={styles.favoriteContent}>
                      <View style={styles.favoriteInfo}>
                        <Text style={styles.favoriteName} numberOfLines={1}>
                          {venue.name}
                        </Text>
                        {venue.neighborhood && (
                          <View style={styles.favoriteRow}>
                            <Ionicons name="location" size={12} color="#52525B" />
                            <Text style={styles.favoriteDetail}>{venue.neighborhood}</Text>
                          </View>
                        )}
                      </View>

                      <TouchableOpacity
                        style={styles.removeButton}
                        onPress={(e) => {
                          e.stopPropagation();
                          removeFavorite(venue.id);
                        }}
                      >
                        <Ionicons name="heart" size={20} color="#EF4444" />
                      </TouchableOpacity>
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          
          <TouchableOpacity style={styles.actionButton}>
            <View style={styles.actionLeft}>
              <View style={styles.actionIcon}>
                <Ionicons name="notifications-outline" size={20} color={colors.violet[600]} />
              </View>
              <Text style={styles.actionText}>Notifications</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.zinc[600]} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton}>
            <View style={styles.actionLeft}>
              <View style={styles.actionIcon}>
                <Ionicons name="location-outline" size={20} color={colors.violet[600]} />
              </View>
              <Text style={styles.actionText}>Change City</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.zinc[600]} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton}>
            <View style={styles.actionLeft}>
              <View style={styles.actionIcon}>
                <Ionicons name="musical-notes-outline" size={20} color={colors.violet[600]} />
              </View>
              <Text style={styles.actionText}>Music Preferences</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.zinc[600]} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton}>
            <View style={styles.actionLeft}>
              <View style={styles.actionIcon}>
                <Ionicons name="share-social-outline" size={20} color={colors.violet[600]} />
              </View>
              <Text style={styles.actionText}>Share Lumina</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.zinc[600]} />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: colors.zinc[900],
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.xl,
  },
  profileInfo: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.violet[600],
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  avatarText: {
    fontSize: 40,
  },
  name: {
    fontSize: typography.sizes['2xl'],
    fontWeight: '600',
    color: colors.white,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[500],
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: spacing.xl,
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: typography.sizes['2xl'],
    fontWeight: '600',
    color: colors.white,
    marginBottom: spacing.xs,
  },
  statLabel: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[600],
  },
  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: colors.zinc[800],
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.lg,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: '600',
    color: colors.white,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing['2xl'],
  },
  emptyTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: '600',
    color: colors.white,
    marginTop: spacing.md,
    marginBottom: spacing.xs,
  },
  emptyText: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[500],
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  exploreButton: {
    backgroundColor: colors.violet[600],
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: 24,
  },
  exploreButtonText: {
    fontSize: typography.sizes.base,
    fontWeight: '600',
    color: colors.white,
  },
  favoritesList: {
    gap: spacing.md,
  },
  favoriteCard: {
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  favoriteGradient: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  favoriteImage: {
    width: 80,
    height: 80,
    backgroundColor: colors.zinc[200],
  },
  favoriteContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
  },
  favoriteInfo: {
    flex: 1,
  },
  favoriteName: {
    fontSize: typography.sizes.base,
    fontWeight: '600',
    color: '#000000',
    marginBottom: spacing.xs,
  },
  favoriteRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  favoriteDetail: {
    fontSize: typography.sizes.xs,
    color: '#52525B',
  },
  removeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FEF2F2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.glass.medium,
    borderWidth: 1,
    borderColor: colors.glass.border,
    borderRadius: 16,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  actionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  actionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.violet[600] + '20',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionText: {
    fontSize: typography.sizes.base,
    fontWeight: '500',
    color: colors.white,
  },
});
