import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, typography, spacing } from '../theme';
import { glassStyles } from '../theme/vibeGradients';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const VIBES = [
  { id: 'upscale', emoji: '✨', label: 'Upscale Lounges', color: colors.violet[500] },
  { id: 'high-energy', emoji: '⚡', label: 'High Energy', color: colors.pink[500] },
  { id: 'rooftop', emoji: '🌃', label: 'Rooftops', color: colors.blue[500] },
  { id: 'chill', emoji: '🍷', label: 'Chill Vibes', color: colors.orange[500] },
  { id: 'date-night', emoji: '❤️', label: 'Date Spots', color: colors.red[500] },
  { id: 'brunch', emoji: '🥂', label: 'Brunch', color: colors.yellow[500] },
];

const MUSIC_GENRES = [
  { id: 'afrobeats', emoji: '🎵', label: 'Afrobeats', color: colors.orange[500] },
  { id: 'hip-hop', emoji: '🎤', label: 'Hip-Hop', color: colors.blue[600] },
  { id: 'edm', emoji: '🎧', label: 'EDM/House', color: colors.purple[500] },
  { id: 'latin', emoji: '💃', label: 'Latin', color: colors.red[500] },
  { id: 'r&b', emoji: '🎹', label: 'R&B', color: colors.pink[500] },
  { id: 'live-music', emoji: '🎸', label: 'Live Music', color: colors.green[500] },
];

export default function OnboardingScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [selectedVibes, setSelectedVibes] = useState<string[]>([]);
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);

  const handleVibeToggle = async (vibeId: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    
    setSelectedVibes(prev =>
      prev.includes(vibeId)
        ? prev.filter(v => v !== vibeId)
        : [...prev, vibeId]
    );
  };

  const handleGenreToggle = async (genreId: string) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    
    setSelectedGenres(prev =>
      prev.includes(genreId)
        ? prev.filter(g => g !== genreId)
        : [...prev, genreId]
    );
  };

  const handleComplete = async () => {
    try {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      
      // Save profile
      const profile = {
        name,
        preferences: [...selectedVibes, ...selectedGenres],
        vibes: selectedVibes,
        musicGenres: selectedGenres,
        onboardingCompleted: true,
        createdAt: new Date().toISOString(),
      };

      await AsyncStorage.setItem('@lumina_profile', JSON.stringify(profile));
      
      // Navigate to home
      router.replace('/(tabs)');
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  const canContinue = () => {
    if (step === 1) return name.trim().length > 0;
    if (step === 2) return selectedVibes.length > 0;
    if (step === 3) return selectedGenres.length > 0;
    return false;
  };

  const handleNext = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    
    if (step < 3) {
      setStep(step + 1);
    } else {
      handleComplete();
    }
  };

  const handleBack = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (step > 1) {
      setStep(step - 1);
    } else {
      router.back();
    }
  };

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientEnd]}
      style={styles.container}
    >
      <View style={[styles.header, { paddingTop: insets.top + spacing.lg }]}>
        <TouchableOpacity
          style={[styles.backButton, glassStyles.liquid]}
          onPress={handleBack}
        >
          <Ionicons name="arrow-back" size={24} color={colors.white} />
        </TouchableOpacity>

        {/* Progress Indicator */}
        <View style={styles.progressContainer}>
          {[1, 2, 3].map((s) => (
            <View
              key={s}
              style={[
                styles.progressDot,
                s === step && styles.progressDotActive,
                s < step && styles.progressDotComplete,
              ]}
            />
          ))}
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Step 1: Name */}
        {step === 1 && (
          <View style={styles.stepContainer}>
            <Text style={styles.stepEmoji}>👋</Text>
            <Text style={styles.stepTitle}>Welcome to Lumina</Text>
            <Text style={styles.stepSubtitle}>
              Your AI-powered nightlife concierge. Let's personalize your experience.
            </Text>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>What's your name?</Text>
              <View style={[styles.input, glassStyles.matte]}>
                <TextInput
                  style={styles.textInput}
                  placeholder="Enter your name"
                  placeholderTextColor={colors.zinc[500]}
                  value={name}
                  onChangeText={setName}
                  autoFocus
                />
              </View>
            </View>
          </View>
        )}

        {/* Step 2: Vibes */}
        {step === 2 && (
          <View style={styles.stepContainer}>
            <Text style={styles.stepEmoji}>✨</Text>
            <Text style={styles.stepTitle}>What's your vibe?</Text>
            <Text style={styles.stepSubtitle}>
              Select the atmospheres you love. Choose as many as you like.
            </Text>

            <View style={styles.optionsGrid}>
              {VIBES.map((vibe) => {
                const isSelected = selectedVibes.includes(vibe.id);
                
                return (
                  <TouchableOpacity
                    key={vibe.id}
                    style={[
                      styles.optionCard,
                      isSelected && styles.optionCardSelected,
                    ]}
                    onPress={() => handleVibeToggle(vibe.id)}
                    activeOpacity={0.7}
                  >
                    <LinearGradient
                      colors={
                        isSelected
                          ? [vibe.color, vibe.color + 'DD']
                          : ['rgba(39, 39, 42, 0.6)', 'rgba(39, 39, 42, 0.4)']
                      }
                      style={[
                        styles.optionCardGradient,
                        isSelected ? glassStyles.liquid : glassStyles.matte,
                      ]}
                    >
                      {isSelected && (
                        <View style={styles.optionCheckmark}>
                          <Ionicons name="checkmark-circle" size={20} color={colors.white} />
                        </View>
                      )}
                      <Text style={styles.optionEmoji}>{vibe.emoji}</Text>
                      <Text style={styles.optionLabel}>{vibe.label}</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        )}

        {/* Step 3: Music */}
        {step === 3 && (
          <View style={styles.stepContainer}>
            <Text style={styles.stepEmoji}>🎵</Text>
            <Text style={styles.stepTitle}>What's your sound?</Text>
            <Text style={styles.stepSubtitle}>
              Select your favorite music genres for the perfect night out.
            </Text>

            <View style={styles.optionsGrid}>
              {MUSIC_GENRES.map((genre) => {
                const isSelected = selectedGenres.includes(genre.id);
                
                return (
                  <TouchableOpacity
                    key={genre.id}
                    style={[
                      styles.optionCard,
                      isSelected && styles.optionCardSelected,
                    ]}
                    onPress={() => handleGenreToggle(genre.id)}
                    activeOpacity={0.7}
                  >
                    <LinearGradient
                      colors={
                        isSelected
                          ? [genre.color, genre.color + 'DD']
                          : ['rgba(39, 39, 42, 0.6)', 'rgba(39, 39, 42, 0.4)']
                      }
                      style={[
                        styles.optionCardGradient,
                        isSelected ? glassStyles.liquid : glassStyles.matte,
                      ]}
                    >
                      {isSelected && (
                        <View style={styles.optionCheckmark}>
                          <Ionicons name="checkmark-circle" size={20} color={colors.white} />
                        </View>
                      )}
                      <Text style={styles.optionEmoji}>{genre.emoji}</Text>
                      <Text style={styles.optionLabel}>{genre.label}</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        )}
      </ScrollView>

      {/* Continue Button */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + spacing.lg }]}>
        <TouchableOpacity
          style={[
            styles.continueButton,
            !canContinue() && styles.continueButtonDisabled,
          ]}
          onPress={handleNext}
          disabled={!canContinue()}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={
              canContinue()
                ? [colors.violet[600], colors.violet[700]]
                : [colors.zinc[800], colors.zinc[700]]
            }
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={[styles.continueButtonGradient, glassStyles.liquid]}
          >
            <Text style={styles.continueButtonText}>
              {step === 3 ? "Let's Go! 🚀" : 'Continue'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color={colors.white} />
          </LinearGradient>
        </TouchableOpacity>

        {step < 3 && (
          <TouchableOpacity
            style={styles.skipButton}
            onPress={() => setStep(step + 1)}
          >
            <Text style={styles.skipButtonText}>Skip for now</Text>
          </TouchableOpacity>
        )}
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
  },
  backButton: {
    alignSelf: 'flex-start',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  progressContainer: {
    flexDirection: 'row',
    gap: spacing.sm,
    justifyContent: 'center',
  },
  progressDot: {
    width: 32,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.zinc[700],
  },
  progressDotActive: {
    backgroundColor: colors.violet[500],
  },
  progressDotComplete: {
    backgroundColor: colors.violet[600],
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.xl,
  },
  stepContainer: {
    alignItems: 'center',
  },
  stepEmoji: {
    fontSize: 64,
    marginBottom: spacing.md,
  },
  stepTitle: {
    fontSize: typography.sizes.xxl,
    fontWeight: '700',
    color: colors.white,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  stepSubtitle: {
    fontSize: typography.sizes.md,
    color: colors.zinc[400],
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: spacing.xl,
    paddingHorizontal: spacing.md,
  },
  inputContainer: {
    width: '100%',
    gap: spacing.sm,
  },
  inputLabel: {
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
  },
  input: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: 16,
  },
  textInput: {
    fontSize: typography.sizes.lg,
    color: colors.white,
    fontWeight: '600',
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
    justifyContent: 'center',
    width: '100%',
  },
  optionCard: {
    width: (SCREEN_WIDTH - spacing.lg * 2 - spacing.md) / 2,
    borderRadius: 16,
    overflow: 'hidden',
  },
  optionCardSelected: {
    transform: [{ scale: 1.05 }],
  },
  optionCardGradient: {
    padding: spacing.lg,
    alignItems: 'center',
    gap: spacing.sm,
    position: 'relative',
    minHeight: 120,
    justifyContent: 'center',
  },
  optionCheckmark: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
  },
  optionEmoji: {
    fontSize: 40,
  },
  optionLabel: {
    fontSize: typography.sizes.sm,
    fontWeight: '600',
    color: colors.white,
    textAlign: 'center',
  },
  footer: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    gap: spacing.md,
  },
  continueButton: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  continueButtonDisabled: {
    opacity: 0.5,
  },
  continueButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  continueButtonText: {
    fontSize: typography.sizes.lg,
    fontWeight: '700',
    color: colors.white,
  },
  skipButton: {
    alignItems: 'center',
    paddingVertical: spacing.sm,
  },
  skipButtonText: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[500],
    fontWeight: '600',
  },
});
