import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  TextInput,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, typography, spacing } from '../theme';
import { glassStyles } from '../theme/vibeGradients';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const CITIES = [
  {
    name: 'Manhattan',
    state: 'NY',
    icon: '🗽',
    description: 'Iconic nightlife, endless options',
    venues: 1470,
    available: true,
  },
  {
    name: 'Brooklyn',
    state: 'NY',
    icon: '🌉',
    description: 'Trendy spots, rooftop vibes',
    venues: 850,
    available: true,
  },
  {
    name: 'Queens',
    state: 'NY',
    icon: '🎭',
    description: 'Diverse culture, hidden gems',
    venues: 420,
    available: true,
  },
  {
    name: 'Bronx',
    state: 'NY',
    icon: '⚾',
    description: 'Authentic vibes, local favorites',
    venues: 280,
    available: true,
  },
  {
    name: 'Jersey City',
    state: 'NJ',
    icon: '🌆',
    description: 'Views & waterfront lounges',
    venues: 245,
    available: true,
  },
  {
    name: 'Hoboken',
    state: 'NJ',
    icon: '🍺',
    description: 'Bar scene, weekend energy',
    venues: 190,
    available: true,
  },
  {
    name: 'Washington DC',
    state: 'DC',
    icon: '🏛️',
    description: 'Political power & nightlife',
    venues: 421,
    available: true,
  },
  {
    name: 'Philadelphia',
    state: 'PA',
    icon: '🔔',
    description: 'Historic meets modern',
    venues: 404,
    available: true,
  },
  {
    name: 'Baltimore',
    state: 'MD',
    icon: '⚓',
    description: 'Harbor vibes, crab cakes',
    venues: 497,
    available: true,
  },
  {
    name: 'Richmond',
    state: 'VA',
    icon: '🌳',
    description: 'Southern charm, craft scene',
    venues: 479,
    available: true,
  },
  {
    name: 'Norfolk',
    state: 'VA',
    icon: '⛵',
    description: 'Navy town, beach access',
    venues: 346,
    available: true,
  },
];

const COMING_SOON_CITIES = [
  { name: 'Miami', state: 'FL', icon: '🌴', description: 'Beach clubs & Latin nights' },
  { name: 'Los Angeles', state: 'CA', icon: '🌟', description: 'Hollywood glamour & rooftops' },
  { name: 'Chicago', state: 'IL', icon: '🌃', description: 'Deep dish & deep house' },
  { name: 'Atlanta', state: 'GA', icon: '🍑', description: 'Hip-hop capital' },
  { name: 'Austin', state: 'TX', icon: '🎸', description: 'Live music every night' },
  { name: 'Boston', state: 'MA', icon: '🦞', description: 'Historic bars & college vibes' },
];

export default function CitySelectModal() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [selectedCity, setSelectedCity] = useState('Manhattan');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadCurrentCity();
  }, []);

  const loadCurrentCity = async () => {
    try {
      const profile = await AsyncStorage.getItem('@lumina_profile');
      if (profile) {
        const data = JSON.parse(profile);
        setSelectedCity(data.city || 'Manhattan');
      }
    } catch (error) {
      console.error('Error loading city:', error);
    }
  };

  const handleSelectCity = async (cityName: string) => {
    try {
      // Haptic feedback on tap
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      
      // Update profile with new city
      const profile = await AsyncStorage.getItem('@lumina_profile');
      const data = profile ? JSON.parse(profile) : {};
      
      data.city = cityName;
      
      await AsyncStorage.setItem('@lumina_profile', JSON.stringify(data));
      
      setSelectedCity(cityName);
      
      // Navigate back after short delay for visual feedback
      setTimeout(() => {
        router.back();
      }, 300);
    } catch (error) {
      console.error('Error saving city:', error);
    }
  };

  const handleComingSoonCity = async (cityName: string) => {
    // Haptic feedback
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    
    // Store interest in AsyncStorage
    try {
      const interests = await AsyncStorage.getItem('@lumina_city_interests');
      const interestList = interests ? JSON.parse(interests) : [];
      
      if (!interestList.includes(cityName)) {
        interestList.push(cityName);
        await AsyncStorage.setItem('@lumina_city_interests', JSON.stringify(interestList));
      }
    } catch (error) {
      console.error('Error storing interest:', error);
    }
  };

  const filteredCities = CITIES.filter(city =>
    city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    city.state.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredComingSoon = COMING_SOON_CITIES.filter(city =>
    city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    city.state.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <LinearGradient
      colors={[colors.gradientStart, colors.gradientEnd]}
      style={styles.container}
    >
      <View style={[styles.header, { paddingTop: insets.top + spacing.lg }]}>
        <TouchableOpacity
          style={[styles.closeButton, glassStyles.liquid]}
          onPress={() => router.back()}
        >
          <Ionicons name="close" size={24} color={colors.white} />
        </TouchableOpacity>
        
        <View style={styles.headerContent}>
          <Text style={styles.title}>Choose Your City</Text>
          <Text style={styles.subtitle}>
            Select your location to get personalized recommendations
          </Text>
        </View>

        {/* Search Bar */}
        <View style={[styles.searchBar, glassStyles.matte]}>
          <Ionicons name="search" size={20} color={colors.zinc[400]} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search cities..."
            placeholderTextColor={colors.zinc[500]}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={20} color={colors.zinc[400]} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Available Cities */}
        <View style={styles.citiesGrid}>
          {filteredCities.map((city) => {
            const isSelected = selectedCity === city.name;
            
            return (
              <TouchableOpacity
                key={city.name}
                style={[
                  styles.cityCard,
                  isSelected && styles.cityCardSelected,
                ]}
                onPress={() => handleSelectCity(city.name)}
                activeOpacity={0.7}
              >
                <LinearGradient
                  colors={
                    isSelected
                      ? [colors.violet[600], colors.violet[700]]
                      : ['rgba(39, 39, 42, 0.6)', 'rgba(39, 39, 42, 0.4)']
                  }
                  style={[
                    styles.cityCardGradient,
                    isSelected ? glassStyles.liquid : glassStyles.matte,
                  ]}
                >
                  {isSelected && (
                    <View style={styles.checkmark}>
                      <Ionicons name="checkmark-circle" size={24} color={colors.white} />
                    </View>
                  )}
                  
                  <Text style={styles.cityIcon}>{city.icon}</Text>
                  
                  <View style={styles.cityInfo}>
                    <Text style={styles.cityName}>{city.name}</Text>
                    <Text style={styles.cityState}>{city.state}</Text>
                  </View>
                  
                  <Text style={styles.cityDescription}>{city.description}</Text>
                  
                  <View style={styles.venueCount}>
                    <Ionicons name="location" size={14} color={colors.violet[400]} />
                    <Text style={styles.venueCountText}>{city.venues} venues</Text>
                  </View>
                </LinearGradient>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Coming Soon Cities */}
        {(searchQuery.length === 0 || filteredComingSoon.length > 0) && (
          <View style={styles.comingSoonSection}>
            <Text style={styles.sectionTitle}>🚀 Coming Soon</Text>
            <Text style={styles.sectionSubtitle}>
              Tap to get notified when these cities launch
            </Text>
            
            <View style={styles.comingSoonGrid}>
              {filteredComingSoon.map((city) => (
                <TouchableOpacity
                  key={city.name}
                  style={styles.comingSoonCard}
                  onPress={() => handleComingSoonCity(city.name)}
                  activeOpacity={0.7}
                >
                  <View style={[styles.comingSoonCardContent, glassStyles.matte]}>
                    <Text style={styles.comingSoonIcon}>{city.icon}</Text>
                    <View style={styles.comingSoonInfo}>
                      <Text style={styles.comingSoonName}>{city.name}</Text>
                      <Text style={styles.comingSoonState}>{city.state}</Text>
                    </View>
                    <View style={styles.notifyBadge}>
                      <Ionicons name="notifications-outline" size={16} color={colors.violet[400]} />
                    </View>
                  </View>
                  <Text style={styles.comingSoonDescription}>{city.description}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
  },
  closeButton: {
    alignSelf: 'flex-start',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  headerContent: {
    gap: spacing.xs,
    marginBottom: spacing.md,
  },
  title: {
    fontSize: typography.sizes.xxl,
    fontWeight: '700',
    color: colors.white,
  },
  subtitle: {
    fontSize: typography.sizes.md,
    color: colors.zinc[400],
    lineHeight: 22,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 16,
  },
  searchInput: {
    flex: 1,
    fontSize: typography.sizes.md,
    color: colors.white,
    paddingVertical: spacing.xs,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
  },
  citiesGrid: {
    gap: spacing.md,
  },
  cityCard: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  cityCardSelected: {
    transform: [{ scale: 1.02 }],
  },
  cityCardGradient: {
    padding: spacing.lg,
    position: 'relative',
  },
  checkmark: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
  },
  cityIcon: {
    fontSize: 48,
    marginBottom: spacing.sm,
  },
  cityInfo: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: spacing.sm,
    marginBottom: spacing.xs,
  },
  cityName: {
    fontSize: typography.sizes.xl,
    fontWeight: '700',
    color: colors.white,
  },
  cityState: {
    fontSize: typography.sizes.sm,
    fontWeight: '600',
    color: colors.zinc[400],
  },
  cityDescription: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[300],
    marginBottom: spacing.md,
    lineHeight: 20,
  },
  venueCount: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  venueCountText: {
    fontSize: typography.sizes.sm,
    color: colors.violet[400],
    fontWeight: '600',
  },
  comingSoonSection: {
    marginTop: spacing.xl,
  },
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: '700',
    color: colors.white,
    marginBottom: spacing.xs,
  },
  sectionSubtitle: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
    marginBottom: spacing.md,
  },
  comingSoonGrid: {
    gap: spacing.sm,
  },
  comingSoonCard: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  comingSoonCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
  },
  comingSoonIcon: {
    fontSize: 32,
  },
  comingSoonInfo: {
    flex: 1,
  },
  comingSoonName: {
    fontSize: typography.sizes.md,
    fontWeight: '600',
    color: colors.white,
  },
  comingSoonState: {
    fontSize: typography.sizes.xs,
    color: colors.zinc[500],
    fontWeight: '600',
  },
  comingSoonDescription: {
    fontSize: typography.sizes.sm,
    color: colors.zinc[400],
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
  },
  notifyBadge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.violet[500] + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
