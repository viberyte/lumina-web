import AsyncStorage from '@react-native-async-storage/async-storage';
import * as AppleAuthentication from 'expo-apple-authentication';
import * as Google from 'expo-auth-session/providers/google';
import * as WebBrowser from 'expo-web-browser';

WebBrowser.maybeCompleteAuthSession();

const API_BASE = 'https://lumina.viberyte.com';

// Google OAuth Config
const GOOGLE_CLIENT_ID_IOS = '1234567890-abcdefghijk.apps.googleusercontent.com';
const GOOGLE_CLIENT_ID_ANDROID = '1234567890-abcdefghijk.apps.googleusercontent.com';
const GOOGLE_CLIENT_ID_WEB = '1234567890-abcdefghijk.apps.googleusercontent.com';

export interface User {
  id: string;
  email: string;
  name: string;
  provider: 'email' | 'google' | 'apple' | 'guest';
  createdAt: string;
  profileData?: any;
}

class AuthService {
  private user: User | null = null;
  private refreshTimer: NodeJS.Timeout | null = null;

  useGoogleAuth() {
    const [request, response, promptAsync] = Google.useAuthRequest({
      iosClientId: GOOGLE_CLIENT_ID_IOS,
      androidClientId: GOOGLE_CLIENT_ID_ANDROID,
      webClientId: GOOGLE_CLIENT_ID_WEB,
    });
    
    return { request, response, promptAsync };
  }

  async signInWithGoogle(accessToken: string): Promise<User> {
    try {
      const userInfoResponse = await fetch('https://www.googleapis.com/userinfo/v2/me', {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      
      const googleUser = await userInfoResponse.json();
      
      const user: User = {
        id: `google_${googleUser.id}`,
        email: googleUser.email,
        name: googleUser.name,
        provider: 'google',
        createdAt: new Date().toISOString(),
      };

      await this.saveUserToBackend(user, accessToken);
      await AsyncStorage.setItem('@lumina_user', JSON.stringify(user));
      await AsyncStorage.setItem('@lumina_auth_token', accessToken);
      
      this.user = user;
      this.startTokenRefresh();
      
      return user;
      
    } catch (error) {
      console.error('Google sign in error:', error);
      throw new Error('Failed to sign in with Google');
    }
  }

  async signInWithApple(): Promise<User> {
    try {
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      const { identityToken, email, fullName } = credential;
      
      const user: User = {
        id: `apple_${credential.user}`,
        email: email || `${credential.user}@appleid.com`,
        name: fullName 
          ? `${fullName.givenName || ''} ${fullName.familyName || ''}`.trim()
          : 'Apple User',
        provider: 'apple',
        createdAt: new Date().toISOString(),
      };

      await this.saveUserToBackend(user, identityToken);
      await AsyncStorage.setItem('@lumina_user', JSON.stringify(user));
      await AsyncStorage.setItem('@lumina_auth_token', identityToken);
      
      this.user = user;
      this.startTokenRefresh();
      
      return user;
      
    } catch (error: any) {
      if (error.code === 'ERR_CANCELED') {
        throw new Error('Sign in cancelled');
      }
      throw error;
    }
  }

  async signInWithEmail(email: string, password: string): Promise<User> {
    try {
      const response = await fetch(`${API_BASE}/api/auth/signin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Invalid credentials');
      }

      const data = await response.json();
      const user: User = {
        id: data.userId,
        email: data.email,
        name: data.name,
        provider: 'email',
        createdAt: data.createdAt,
        profileData: data.profileData,
      };

      await AsyncStorage.setItem('@lumina_user', JSON.stringify(user));
      await AsyncStorage.setItem('@lumina_auth_token', data.token);
      await AsyncStorage.setItem('@lumina_refresh_token', data.refreshToken);
      
      this.user = user;
      this.startTokenRefresh();
      
      return user;
      
    } catch (error: any) {
      throw new Error(error.message || 'Sign in failed');
    }
  }

  async signUpWithEmail(email: string, password: string, name: string): Promise<User> {
    try {
      const response = await fetch(`${API_BASE}/api/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Sign up failed');
      }

      const data = await response.json();
      const user: User = {
        id: data.userId,
        email: data.email,
        name,
        provider: 'email',
        createdAt: data.createdAt,
      };

      await AsyncStorage.setItem('@lumina_user', JSON.stringify(user));
      await AsyncStorage.setItem('@lumina_auth_token', data.token);
      await AsyncStorage.setItem('@lumina_refresh_token', data.refreshToken);
      
      this.user = user;
      this.startTokenRefresh();
      
      return user;
      
    } catch (error: any) {
      throw new Error(error.message || 'Sign up failed');
    }
  }

  async continueAsGuest(): Promise<User> {
    const guest: User = {
      id: `guest-${Date.now()}`,
      email: '',
      name: 'Guest',
      provider: 'guest',
      createdAt: new Date().toISOString(),
    };
    
    await AsyncStorage.setItem('@lumina_user', JSON.stringify(guest));
    await AsyncStorage.setItem('@lumina_auth_token', 'guest_token');
    
    this.user = guest;
    return guest;
  }

  async getCurrentUser(): Promise<User | null> {
    if (this.user) return this.user;
    
    try {
      const userData = await AsyncStorage.getItem('@lumina_user');
      if (userData) {
        this.user = JSON.parse(userData);
        this.startTokenRefresh();
        return this.user;
      }
    } catch (error) {
      console.error('Error loading user:', error);
    }
    
    return null;
  }

  async refreshAuthToken(): Promise<void> {
    try {
      const refreshToken = await AsyncStorage.getItem('@lumina_refresh_token');
      if (!refreshToken) {
        throw new Error('No refresh token');
      }

      const response = await fetch(`${API_BASE}/api/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken }),
      });

      if (!response.ok) {
        throw new Error('Token refresh failed');
      }

      const data = await response.json();
      await AsyncStorage.setItem('@lumina_auth_token', data.token);
      
      console.log('✅ Token refreshed');
      
    } catch (error) {
      console.error('Token refresh error:', error);
      await this.signOut();
    }
  }

  private startTokenRefresh(): void {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
    }
    
    this.refreshTimer = setInterval(() => {
      this.refreshAuthToken();
    }, 6 * 24 * 60 * 60 * 1000);
  }

  async signOut(): Promise<void> {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
    }
    
    await AsyncStorage.multiRemove([
      '@lumina_user',
      '@lumina_auth_token',
      '@lumina_refresh_token',
    ]);
    
    this.user = null;
  }

  async isAuthenticated(): Promise<boolean> {
    const user = await this.getCurrentUser();
    return user !== null;
  }

  async getAuthToken(): Promise<string | null> {
    return await AsyncStorage.getItem('@lumina_auth_token');
  }

  private async saveUserToBackend(user: User, token: string): Promise<void> {
    try {
      await fetch(`${API_BASE}/api/auth/save-user`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(user),
      });
    } catch (error) {
      console.error('Error saving user to backend:', error);
    }
  }
}

export default new AuthService();
