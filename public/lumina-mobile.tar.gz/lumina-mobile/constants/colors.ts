export default {
  violet: {
    100: '#ede9fe',
    200: '#ddd6fe',
    300: '#c4b5fd',
    400: '#a78bfa',
    500: '#8b5cf6',
    600: '#7c3aed',
    700: '#6d28d9',
  },
  gray: {
    300: '#d1d5db',
    400: '#9ca3af',
    500: '#6b7280',
  },
  red: {
    500: '#ef4444',
  },
};
