export const colors = {
  black: '#000000',
  gradientStart: '#050508',
  gradientEnd: '#111119',
  
  // Primary
  violet: {
    500: '#8B5CF6',
    600: '#7C3AED',
  },
  purple: {
    600: '#9333EA',
  },
  
  // UI Elements
  white: '#FFFFFF',
  zinc: {
    50: '#FAFAFA',
    100: '#F4F4F5',
    400: '#A1A1AA',
    500: '#71717A',
    600: '#52525B',
    700: '#3F3F46',
    800: '#27272A',
    900: '#18181B',
    950: '#09090B',
  },
  
  // Glass morphism
  glass: {
    light: 'rgba(255, 255, 255, 0.03)',
    medium: 'rgba(255, 255, 255, 0.06)',
    border: 'rgba(255, 255, 255, 0.08)',
  }
};
